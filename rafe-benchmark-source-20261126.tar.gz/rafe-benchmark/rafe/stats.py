"""Paired inference over series and temporal blocks; draws are nuisance replicates."""
import itertools
import numpy as np

def holm(pvalues):
    p = np.asarray(pvalues, float)
    if not np.isfinite(p).all() or np.any((p < 0) | (p > 1)):
        raise ValueError("Invalid p-values")
    order = np.argsort(p, kind="stable")
    adjusted = np.minimum(1, np.maximum.accumulate(p[order] * np.arange(len(p), 0, -1)))
    out = np.empty_like(p)
    out[order] = adjusted
    return out

def sign_flip(v, *, seed=1729, samples=100000):
    v = np.asarray(v, float)
    if v.ndim != 1 or not np.isfinite(v).all() or len(v) < 2:
        raise ValueError("At least two finite temporal units are required")
    observed = abs(v.mean())
    if len(v) <= 16:
        signs = np.array(list(itertools.product([-1., 1.], repeat=len(v))))
        p = np.mean(abs(signs @ v / len(v)) >= observed - 1e-14)
        return float(p), "exact"
    rng = np.random.default_rng(seed)
    count = 0
    for lo in range(0, samples, 5000):
        n = min(5000, samples - lo)
        signs = 2 * rng.integers(0, 2, (n, len(v))) - 1
        count += np.sum(abs(signs @ v / len(v)) >= observed - 1e-14)
    return float((count + 1) / (samples + 1)), "monte_carlo"

def errors(forecast, target):
    f, y = np.asarray(forecast, float), np.asarray(target, float)
    observed = np.isfinite(y)
    if f.shape != y.shape or not np.isfinite(f).all() or not observed.any(1).all():
        raise ValueError("Forecast/target mismatch or target without observations")
    difference = np.where(observed, f - np.where(observed, y, 0), 0)
    count = observed.sum(1)
    return (difference * difference).sum(1) / count, abs(difference).sum(1) / count

def cells(query_error, series, block):
    """[draw,query] -> log mean error [draw,series,block]."""
    series_ids, blocks = np.unique(series), np.unique(block)
    out = np.full((len(query_error), len(series_ids), len(blocks)), np.nan)
    for i, s in enumerate(series_ids):
        for j, b in enumerate(blocks):
            rows = (series == s) & (block == b)
            if rows.any():
                out[:, i, j] = np.log(np.maximum(query_error[:, rows].mean(-1), 1e-12))
    if not np.isfinite(out).all():
        raise ValueError("Inference requires observations in every series/block cell")
    return out

def contrast(la, lb, *, seed=1729, bootstrap=10000, cluster_pairs=True):
    delta = np.asarray(la) - np.asarray(lb)
    if delta.ndim != 3 or not np.isfinite(delta).all():
        raise ValueError("Contrast requires finite paired [draw,series,block] cells")
    nd, ns, nb = delta.shape
    if nb < 2:
        raise ValueError("Insufficient temporal units")
    v = delta.mean(axis=(0, 1))
    p, kind = sign_flip(v, seed=seed)
    sensitivity = None
    if cluster_pairs and nb >= 4 and nb % 2 == 0:
        pc, kc = sign_flip(v.reshape(-1, 2).mean(1), seed=seed)
        sensitivity = {"p": pc, "units": nb // 2, "test": kc}
    rng = np.random.default_rng(seed)
    samples = []
    for lo in range(0, bootstrap, 500):
        n = min(500, bootstrap - lo)
        di = rng.integers(0, nd, (n, nd))
        si = rng.integers(0, ns, (n, ns))
        bi = rng.integers(0, nb, (n, nb))
        resampled = delta[di[:, :, None, None], si[:, None, :, None], bi[:, None, None, :]]
        samples.append(100 * (1 - np.exp(resampled.mean(axis=(1, 2, 3)))))
    intervals = np.percentile(np.concatenate(samples), [2.5, 97.5]).tolist()
    return {"improvement_percent": float(100 * (1 - np.exp(v.mean()))),
            "CI95": intervals, "p": p, "test": kind,
            "temporal_units": nb, "series": ns, "bank_draws": nd,
            "blocks_improved": int(np.sum(v < 0)),
            "block_log_ratios": v.tolist(), "cluster_sensitivity": sensitivity}
