"""Create a new method comparison from a committed run, without original weights."""
from pathlib import Path
import copy
from .io import dump, protect_output
from .runner import verify, _verify_predictions

def extend(run_dir, out_path, *, factory, name, baselines, kwargs=None,
           suites=None, cohorts=None, horizons=None):
    run = Path(run_dir).resolve()
    spec, lock = verify(run)
    commit = _verify_predictions(run)
    if not baselines or name in baselines or len(set(baselines)) != len(baselines):
        raise ValueError("Choose distinct committed baselines and a new output name")
    if factory.count(":") != 1:
        raise ValueError("Factory must be module:Class")
    cases = []
    for original in spec["cases"]:
        if suites and original.get("suite","main") not in suites:
            continue
        if cohorts and original["cohort"] not in cohorts:
            continue
        if horizons and original["H"] not in horizons:
            continue
        case = copy.deepcopy(original)
        outputs = commit["outputs"][case["id"]]
        missing = set(baselines)-set(outputs)
        if missing:
            raise ValueError(f"Baselines unavailable in {case['id']}: {sorted(missing)}")
        case["references"] = {b:{"path":str(run/outputs[b]),"key":b} for b in baselines}
        cases.append(case)
    if not cases:
        raise ValueError("No committed cases match the selected workload")
    selected_policies = {c["policy"] for c in cases}
    config = {"format_version":1, "scope":"synthetic" if spec["scope"]=="synthetic" else "retrospective",
        "cases":cases, "plugins":[{"factory":factory,"outputs":[name],"kwargs":kwargs or {}}],
        "baselines":{name:baselines[0]}, "rank_pairs":[[name,b] for b in baselines[1:]],
        "policy_contrasts":[p for p in spec.get("policy_contrasts",[]) if set(p)<=selected_policies],
        "batch_size":spec.get("batch_size",32), "bootstrap":spec.get("bootstrap",10000),
        "stat_seed":spec.get("stat_seed",1729),
        "provenance_files":[str(run/p) for p in ("config.json","execution_lock.json","prediction_commit.json")],
        "derived_from_committed_run":str(run),
        "derivation_note":"Only the new plugin is inferred; existing forecasts are frozen references. Previously observed data remain retrospective."}
    out = protect_output(out_path)
    dump(out,config)
    return {"config":str(out), "cases":len(cases), "scope":config["scope"],
            "new_method":name, "frozen_baselines":baselines}
