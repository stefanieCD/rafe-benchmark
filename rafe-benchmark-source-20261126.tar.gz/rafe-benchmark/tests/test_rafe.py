import tempfile
import unittest
import csv
import json
from pathlib import Path
import numpy as np
from rafe.io import load, dump, protect_output, sha
from rafe.schema import Batch, validate_inputs, budget_summary
from rafe.stats import holm, sign_flip, contrast, errors
from rafe.prepare import demo, Series, select_policy, read_series
from rafe.runner import freeze, predict, score, verify, replay
from rafe.report import report
from rafe.snapshot import export
from rafe.extend import extend

class StatisticsTests(unittest.TestCase):
    def test_holm_known_example(self):
        np.testing.assert_allclose(holm([.01, .04, .03]), [.03, .06, .06])

    def test_exact_temporal_test(self):
        p, kind = sign_flip(np.ones(12))
        self.assertEqual(kind, "exact")
        self.assertEqual(p, 2/4096)
        self.assertEqual(sign_flip(np.zeros(12))[0], 1)

    def test_constant_error_ratio_and_draw_replication(self):
        a = np.zeros((1, 3, 12))
        b = np.full_like(a, np.log(4))
        first = contrast(a, b, bootstrap=100)
        second = contrast(np.repeat(a, 5, 0), np.repeat(b, 5, 0), bootstrap=100)
        self.assertAlmostEqual(first["improvement_percent"], 75)
        self.assertEqual(first["p"], second["p"])
        self.assertEqual(first["temporal_units"], second["temporal_units"])
        np.testing.assert_allclose(first["CI95"], [75, 75])

    def test_observed_targets_are_not_imputed(self):
        mse, mae = errors(np.zeros((1, 3)), np.array([[1., np.nan, 3.]]))
        np.testing.assert_array_equal(mse, [5])
        np.testing.assert_array_equal(mae, [2])

class MemoryTests(unittest.TestCase):
    def setUp(self):
        self.values = np.sin(np.arange(1000)/12).astype(np.float32)
        self.series = Series(self.values, self.values, 100, 32, 8)

    def test_same_population_different_returned_identity(self):
        a = select_policy(self.series, 700, 11, 0, 0, "U16_slots", 10)
        b = select_policy(self.series, 700, 11, 0, 0, "U16_unique", 10)
        self.assertEqual(len(np.unique(a[2])), 3)
        self.assertEqual(len(np.unique(b[2])), 10)
        self.assertEqual(a[3:], b[3:])
        self.assertTrue(np.all(b[2]+8 <= 700))

    def test_copy_control_preserves_content(self):
        a = select_policy(self.series, 700, 11, 0, 0, "dup5_balanced", 10)
        b = select_policy(self.series, 700, 11, 0, 0, "dup5_concentrated", 10)
        np.testing.assert_array_equal(np.unique(a[2]), np.unique(b[2]))
        self.assertEqual(max(np.unique(b[2], return_counts=True)[1]), 6)

    def test_future_record_rejected(self):
        with self.assertRaises(ValueError):
            self.series.record(np.array([699]), 700)

    def test_plugin_schema_has_no_targets(self):
        self.assertNotIn("target", Batch.__dataclass_fields__)
        self.assertNotIn("targets", Batch.__dataclass_fields__)

    def test_frozen_research_output_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            frozen = Path(tmp)/"legacy_result"
            dump(frozen/"execution_lock.json", {"format":"legacy.study"})
            with self.assertRaises(ValueError):
                protect_output(frozen/"new_output/changed.json")

    def test_inconsistent_copies_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            config = load(demo(Path(tmp)/"demo")["config"])
            case = config["cases"][0]
            with np.load(case["queries"]) as z: q = {k:z[k] for k in z.files}
            with np.load(case["bank"]) as z: b = {k:z[k].copy() for k in z.files}
            b["record_end"][:,1] = b["record_end"][:,0]
            b["records"][:,1] = b["records"][:,0] + 1
            with self.assertRaisesRegex(ValueError,"inconsistent"):
                validate_inputs(q,b,case["H"],case["K"])

    def test_invalid_temporal_and_budget_metadata_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            case = load(demo(Path(tmp)/"demo")["config"])["cases"][0]
            with np.load(case["queries"]) as z: q = {k:z[k] for k in z.files}
            with np.load(case["bank"]) as z: b = {k:z[k] for k in z.files}
            for field,values in [("origin",q["origin"].astype(float)),("U",np.array(1)),("N",np.array(-1))]:
                with self.subTest(field=field):
                    qq,bb=dict(q),dict(b)
                    if field=="origin":qq[field]=values
                    else:bb[field]=values
                    with self.assertRaises(ValueError):validate_inputs(qq,bb,case["H"],case["K"])

    def test_csv_import_checks_exact_hourly_spacing(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/"series.csv"
            entry={"path":str(p),"time_column":"time"}
            p.write_text("time,value\n2025-01-01T12:10:00Z,1\n2025-01-01T13:10:00Z,2\n")
            values,observed,start=read_series(Path(tmp)/"manifest.json",entry)
            np.testing.assert_array_equal(values,[1,2])
            np.testing.assert_array_equal(values,observed)
            p.write_text("time,value\n2025-01-01T12:10:00Z,1\n2025-01-01T13:20:00Z,2\n")
            with self.assertRaisesRegex(ValueError,"regular hourly"):
                read_series(Path(tmp)/"manifest.json",entry)

class PipelineTests(unittest.TestCase):
    def test_extend_committed_run_uses_frozen_baselines(self):
        with tempfile.TemporaryDirectory() as tmp:
            out=Path(tmp)
            config=demo(out/"data")["config"]
            run=out/"original";freeze(config,run);predict(run);score(run)
            derived=out/"new_config.json"
            result=extend(run,derived,factory="rafe.toy:Persistence",name="new_method",baselines=["persistence"],horizons=[8])
            self.assertEqual(result["cases"],9)
            self.assertEqual(load(derived)["plugins"][0]["outputs"],["new_method"])
            rerun=out/"new_run";freeze(derived,rerun);predict(rerun);score(rerun)
            comparisons=load(rerun/"scores.json")["comparisons"]
            self.assertTrue(all(c["improvement_percent"]==0 for c in comparisons))
            with self.assertRaisesRegex(ValueError,"unavailable"):
                extend(run,out/"bad.json",factory="rafe.toy:Persistence",name="new_method",baselines=["unknown"])

    def test_complete_portable_pipeline_and_single_score(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp)/"demo"
            config = demo(out)["config"]
            run = Path(tmp)/"run"
            result = freeze(config, run)
            self.assertEqual(result["cases"], 9)
            with self.assertRaises(FileNotFoundError):
                score(run)
            self.assertFalse((run/"scoring_started.json").exists())
            commit = predict(run)
            self.assertTrue(commit["all_forecasts_committed_before_scoring"])
            value = score(run)
            self.assertGreater(value["comparisons"], 0)
            self.assertEqual(value["unavailable"], 0)
            paths = report(run)
            self.assertTrue(Path(paths["html"]).exists())
            with Path(paths["csv"]).open() as f:
                rows=list(csv.DictReader(f))
            first=load(run/"scores.json")["comparisons"][0]
            self.assertEqual(float(rows[0]["CI95_low"]),first["CI95"][0])
            self.assertEqual(float(rows[0]["cluster_holm_p"]),first["cluster_sensitivity"]["holm_p"])
            self.assertEqual(len(json.loads(rows[0]["lhs_pooled_budget_json"])),3)
            original_score = (run/"scores.json").read_bytes()
            self.assertEqual(replay(run)["maximum_numeric_difference"], 0)
            self.assertEqual(original_score, (run/"scores.json").read_bytes())
            snapshot = Path(tmp)/"snapshot"
            export(run, snapshot)
            original_lock=load(run/"execution_lock.json")
            source=next(p for p in original_lock["files"] if p.endswith("rafe/runner.py"))
            self.assertEqual(sha(snapshot/"source/rafe/runner.py"),original_lock["files"][source])
            exported_lock=load(snapshot/"execution_lock.json")
            included=set(exported_lock["files"].values())
            self.assertTrue(all(p["sha256"] not in included for p in exported_lock["omitted_provenance_hashes"]))
            moved = Path(tmp)/"moved_snapshot"
            snapshot.rename(moved)
            verify(moved)
            self.assertEqual(replay(moved)["maximum_numeric_difference"], 0)
            report(moved)
            with self.assertRaises(FileExistsError):
                score(run)
            with self.assertRaises(ValueError):
                predict(run)

    def test_modified_inputs_detected(self):
        with tempfile.TemporaryDirectory() as tmp:
            config = demo(Path(tmp)/"demo")["config"]
            run = Path(tmp)/"run"
            freeze(config, run)
            case = load(config)["cases"][0]
            with open(case["targets"], "ab") as f:
                f.write(b"tampered")
            with self.assertRaises(ValueError):
                verify(run)

if __name__ == "__main__":
    unittest.main()
