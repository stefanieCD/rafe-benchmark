"""Freeze -> predict -> commit -> score, with resumable prediction receipts."""
from pathlib import Path
import gc
import importlib
import importlib.util
import json
import time
from collections import defaultdict
import numpy as np
from .io import dump, load, sha, now, resolve, protect_output
from .schema import Batch, validate_inputs, validate_forecasts, budget_summary
from . import stats

def arrays(path):
    with np.load(path, allow_pickle=False) as z:
        return {k: z[k] for k in z.files}

def freeze(config_path, run_dir):
    run = protect_output(run_dir)
    if (run / "execution_lock.json").exists():
        raise FileExistsError("Run is already frozen; use a new run directory for another configuration")
    spec = load(config_path)
    if spec.get("format_version") != 1 or spec.get("scope") not in ("retrospective", "confirmation", "synthetic"):
        raise ValueError("Specify format_version=1 and the study scope")
    outputs = [n for p in spec["plugins"] for n in p["outputs"]]
    if int(spec.get("batch_size", 32)) < 1 or int(spec.get("bootstrap", 10000)) < 1:
        raise ValueError("Batch size and bootstrap replicates must be positive")
    if len(outputs) != len(set(outputs)):
        raise ValueError("Output names must be unique across plugins")
    ids, files, budgets = set(), {}, {}
    for case in spec["cases"]:
        case["H"], case["K"], case["draw"] = int(case["H"]), int(case["K"]), int(case["draw"])
        if case["id"] in ids or not case["id"].replace("_", "").replace("-", "").isalnum():
            raise ValueError("Case identifiers must be unique and safe filenames")
        ids.add(case["id"])
        for key in ("queries", "bank", "targets"):
            case[key] = str(resolve(config_path, case[key]))
            files[case[key]] = sha(case[key])
        query, bank = arrays(case["queries"]), arrays(case["bank"])
        validate_inputs(query, bank, int(case["H"]), int(case["K"]))
        if int(case.get("step_seconds", 3600)) != int(query.get("step_seconds", 3600)):
            raise ValueError("Case and query sampling intervals disagree")
        budgets[case["id"]] = budget_summary(bank)
        for reference in case.get("references", {}).values():
            reference["path"] = str(resolve(config_path, reference["path"]))
            files[reference["path"]] = sha(reference["path"])
        case.setdefault("suite", "main")
    for p in spec["plugins"]:
        module, name = p["factory"].split(":")
        origin = importlib.util.find_spec(module).origin
        if origin:
            files[str(Path(origin).resolve())] = sha(origin)
    for p in Path(__file__).parent.glob("*.py"):
        files[str(p.resolve())] = sha(p)
    for value in spec.get("provenance_files", []):
        p = resolve(config_path, value)
        files[str(p)] = sha(p)
    run.mkdir(parents=True, exist_ok=True)
    dump(run / "config.json", spec)
    files[str(run / "config.json")] = sha(run / "config.json")
    dump(run / "execution_lock.json", {
        "format": "rafe.run.v1", "sealed_at_utc": now(), "scope": spec["scope"], "files": files,
        "cases": len(ids), "budgets": budgets,
        "query_targets_parsed_during_freeze": False,
        "prediction_plugin_contract": "Batch contains no query targets",
    })
    return {"run": str(run), "cases": len(ids), "scope": spec["scope"]}

def verify(run_dir):
    run = Path(run_dir).resolve()
    lock = load(run / "execution_lock.json")
    for p, expected in lock["files"].items():
        if sha(resolve(run/"execution_lock.json", p)) != expected:
            raise ValueError(f"Frozen input or code changed: {p}")
    spec = load(run / "config.json")
    for case in spec["cases"]:
        for field in ("queries", "bank", "targets"):
            case[field] = str(resolve(run/"config.json", case[field]))
        for ref in case.get("references", {}).values():
            ref["path"] = str(resolve(run/"config.json", ref["path"]))
    return spec, lock

def _write_prediction(run, case, plugin_id, values, seconds):
    path = run / "predictions" / f"{case['id']}__{plugin_id}.npz"
    receipt = path.with_suffix(".json")
    if path.exists() or receipt.exists():
        raise FileExistsError(f"Uncommitted or conflicting prediction file: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez(path, **values)
    dump(receipt, {"sha256": sha(path), "committed_at_utc": now(),
                   "execution_lock_sha256": sha(run / "execution_lock.json"),
                   "case": case["id"], "outputs": sorted(values),
                   "seconds": seconds, "targets_passed_to_plugin": False})
    return path

def _existing(run, case, plugin_id):
    path = run / "predictions" / f"{case['id']}__{plugin_id}.npz"
    receipt = path.with_suffix(".json")
    if receipt.exists():
        record = load(receipt)
        if sha(path) != record["sha256"] or record["execution_lock_sha256"] != sha(run / "execution_lock.json"):
            raise ValueError(f"Prediction commitment mismatch: {path}")
        return path
    if path.exists():
        raise ValueError(f"Prediction exists without a commitment: {path}")
    return None

def predict(run_dir):
    run = protect_output(run_dir)
    spec, lock = verify(run)
    if lock.get("replay_only"):
        raise ValueError("This exported snapshot is for replay; freeze a new run to add a method")
    if (run / "scoring_started.json").exists():
        raise ValueError("Cannot generate predictions after scoring has started")
    if (run / "prediction_commit.json").exists():
        _verify_predictions(run)
        return load(run / "prediction_commit.json")
    files, output_map = {}, defaultdict(dict)
    for case in spec["cases"]:
        references = case.get("references", {})
        if not references:
            continue
        path = _existing(run, case, "references")
        if path is None:
            q = len(arrays(case["queries"])["context"])
            values = {}
            for name, ref in references.items():
                if Path(ref["path"]).suffix == ".npy":
                    values[name] = np.load(ref["path"], allow_pickle=False)
                else:
                    values[name] = arrays(ref["path"])[ref["key"]]
            validate_forecasts(values, references, q, case["H"])
            path = _write_prediction(run, case, "references", values, 0.0)
        files[str(path.relative_to(run))] = sha(path)
        output_map[case["id"]].update({n: str(path.relative_to(run)) for n in references})
    for pi, p in enumerate(spec["plugins"]):
        plugin = None
        try:
            for case in spec["cases"]:
                requested = tuple(n for n in p["outputs"] if n not in case.get("references", {}))
                if not requested:
                    continue
                plugin_id = f"plugin{pi}"
                path = _existing(run, case, plugin_id)
                if path is None:
                    if plugin is None:
                        module, name = p["factory"].split(":")
                        plugin = getattr(importlib.import_module(module), name)(**p.get("kwargs", {}))
                    query, bank = arrays(case["queries"]), arrays(case["bank"])
                    q = validate_inputs(query, bank, case["H"], case["K"])
                    output, batch_size = defaultdict(list), int(spec.get("batch_size", 32))
                    tick = time.monotonic()
                    for lo in range(0, q, batch_size):
                        sl = slice(lo, min(q, lo + batch_size))
                        batch = Batch(query["context"][sl], bank["records"][sl], bank["distance"][sl],
                                      bank["record_end"][sl], query["origin"][sl],
                                      case["H"], case["K"], requested, int(query.get("step_seconds", 3600)))
                        values = plugin.predict(batch)
                        validate_forecasts(values, requested, len(batch.context), case["H"])
                        for name, value in values.items():
                            output[name].append(np.asarray(value, np.float32))
                    values = {n: np.concatenate(v) for n, v in output.items()}
                    path = _write_prediction(run, case, plugin_id, values, time.monotonic() - tick)
                    print(f"PREDICTED {case['id']} {','.join(requested)} {q} queries", flush=True)
                files[str(path.relative_to(run))] = sha(path)
                output_map[case["id"]].update({n: str(path.relative_to(run)) for n in requested})
        finally:
            if plugin is not None and hasattr(plugin, "close"):
                plugin.close()
            del plugin
            gc.collect()
    for case in spec["cases"]:
        required = set(n for p in spec["plugins"] for n in p["outputs"]) | set(case.get("references", {}))
        if set(output_map[case["id"]]) != required:
            raise ValueError(f"Incomplete predictions: {case['id']}")
    record = {"committed_at_utc": now(), "files": files, "outputs": dict(output_map),
              "execution_lock_sha256": sha(run / "execution_lock.json"),
              "all_forecasts_committed_before_scoring": True, "scope": spec["scope"]}
    dump(run / "prediction_commit.json", record)
    return record

def _verify_predictions(run):
    record = load(run / "prediction_commit.json")
    if record["execution_lock_sha256"] != sha(run / "execution_lock.json"):
        raise ValueError("Prediction/configuration mismatch")
    for p, expected in record["files"].items():
        if sha(run / p) != expected:
            raise ValueError(f"Prediction modified: {p}")
    return record

def _compute_scores(run_dir, *, write):
    run = protect_output(run_dir)
    spec, lock = verify(run)
    commit = _verify_predictions(run)
    # Create this marker before interpreting a single target value.
    if write:
        dump(run / "scoring_started.json", {"started_at_utc": now(),
             "prediction_commit_sha256": sha(run / "prediction_commit.json")})
    grouped = defaultdict(list)
    for case in spec["cases"]:
        grouped[(case["suite"], case["cohort"], case["H"], case["K"], case["policy"])].append(case)
    data, profiles = {}, []
    for key, cases in grouped.items():
        cases.sort(key=lambda c: c["draw"])
        query = arrays(cases[0]["queries"])
        target = arrays(cases[0]["targets"])["target"]
        methods = set(commit["outputs"][cases[0]["id"]])
        for c in cases:
            if set(commit["outputs"][c["id"]]) != methods:
                raise ValueError("Paired draws have different methods")
            other = arrays(c["queries"])
            for n in ("context", "series", "family", "block", "origin"):
                np.testing.assert_array_equal(query[n], other[n])
            if int(query.get("step_seconds", 3600)) != int(other.get("step_seconds", 3600)):
                raise ValueError("Paired draws use different sampling intervals")
            np.testing.assert_array_equal(target, arrays(c["targets"])["target"])
        method_errors = {}
        for method in sorted(methods):
            mse, mae = [], []
            for c in cases:
                path = run / commit["outputs"][c["id"]][method]
                forecast = arrays(path)[method]
                se, ae = stats.errors(forecast, target)
                mse.append(se)
                mae.append(ae)
            method_errors[method] = {"MSE": np.stack(mse), "MAE": np.stack(mae)}
            for family in ["pooled", *np.unique(query["family"]).tolist()]:
                rows = np.ones(len(target), bool) if family == "pooled" else query["family"] == family
                log = stats.cells(np.stack(mse)[:, rows], query["series"][rows], query["block"][rows])
                profiles.append(dict(zip(("suite", "cohort", "H", "K", "policy"), key),
                    method=method, family=family, macro_cell_MSE=float(np.exp(log).mean()),
                    query_mean_MSE=float(np.stack(mse)[:, rows].mean()),
                    geometric_mean_cell_MSE=float(np.exp(log.mean())),
                    query_mean_MAE=float(np.stack(mae)[:, rows].mean()),
                    queries=int(rows.sum()), draws=len(cases)))
        data[key] = (query, method_errors)
    comparisons = []
    unavailable = []
    boot = int(spec.get("bootstrap", 10000))

    def compare(left_key, right_key, left_method, right_method, kind):
        if right_key not in data or left_method not in data[left_key][1] or right_method not in data[right_key][1]:
            unavailable.append({"lhs": list(left_key) + [left_method], "rhs": list(right_key) + [right_method]})
            return
        q, le = data[left_key]
        qr, re = data[right_key]
        for name in ("context", "series", "family", "block", "origin"):
            np.testing.assert_array_equal(q[name], qr[name])
        if int(q.get("step_seconds", 3600)) != int(qr.get("step_seconds", 3600)):
            raise ValueError("Paired policies use different sampling intervals")
        suite, cohort, horizon, slots, policy = left_key
        for family in ["pooled", *np.unique(q["family"]).tolist()]:
            rows = np.ones(len(q["context"]), bool) if family == "pooled" else q["family"] == family
            for metric in ("MSE", "MAE"):
                la = stats.cells(le[left_method][metric][:, rows], q["series"][rows], q["block"][rows])
                lb = stats.cells(re[right_method][metric][:, rows], q["series"][rows], q["block"][rows])
                result = stats.contrast(la, lb, seed=int(spec.get("stat_seed", 1729)), bootstrap=boot)
                if kind == "native":
                    test_family = (kind, suite, cohort, horizon, slots, family, metric, right_method)
                elif kind == "memory":
                    test_family = (kind, suite, cohort, horizon, slots, family, metric, left_method)
                else:
                    test_family = (kind, suite, cohort, horizon, slots, family, metric, left_method, right_method)
                comparisons.append({"suite": suite, "cohort": cohort, "H": horizon, "K": slots,
                    "family": family, "metric": metric, "kind": kind,
                    "lhs_method": left_method, "rhs_method": right_method,
                    "lhs_policy": policy, "rhs_policy": right_key[-1],
                    "test_family": list(test_family), **result})
    for key, (query, methods) in data.items():
        for method, native in spec.get("baselines", {}).items():
            if method in methods and method != native:
                compare(key, key, method, native, "native")
        for pair in spec.get("rank_pairs", []):
            if isinstance(pair, dict):
                if key[0] not in pair.get("suites", [key[0]]):
                    continue
                left, right = pair["methods"]
            else:
                left, right = pair
            compare(key, key, left, right, "ranking")
        for left_policy, right_policy in spec.get("policy_contrasts", []):
            if key[-1] == left_policy:
                rk = key[:-1] + (right_policy,)
                for method in sorted(methods):
                    if method not in set(spec.get("baselines", {}).values()):
                        compare(key, rk, method, method, "memory")
    families = defaultdict(list)
    for i, c in enumerate(comparisons):
        families[tuple(c["test_family"])].append(i)
    for ids in families.values():
        corrected = stats.holm([comparisons[i]["p"] for i in ids])
        sensitivity_ids = [i for i in ids if comparisons[i]["cluster_sensitivity"] is not None]
        pc = stats.holm([comparisons[i]["cluster_sensitivity"]["p"] for i in sensitivity_ids])
        for i, value in zip(ids, corrected):
            comparisons[i]["holm_p"] = float(value)
            comparisons[i]["family_size"] = len(ids)
        for i, value in zip(sensitivity_ids, pc):
            comparisons[i]["cluster_sensitivity"]["holm_p"] = float(value)
    result = {"scored_at_utc": now(), "scope": spec["scope"], "profiles": profiles,
              "comparisons": comparisons, "unavailable_comparisons": unavailable,
              "prediction_commit_sha256": sha(run / "prediction_commit.json"),
              "bootstrap": boot, "stat_seed": spec.get("stat_seed", 1729),
              "notes": ["Intervals are nominal paired crossed-bootstrap intervals.",
                        "Sign-flip validity requires joint sign symmetry of the temporal units.",
                        "Memory draws are nuisance replicates, not independent temporal samples.",
                        "Retrospective benchmark scores are not blind confirmation results."]}
    if write:
        dump(run / "scores.json", result)
    return result

def score(run_dir):
    result = _compute_scores(run_dir, write=True)
    return {"profiles": len(result["profiles"]), "comparisons": len(result["comparisons"]),
            "unavailable": len(result["unavailable_comparisons"]), "scope": result["scope"]}

def replay(run_dir):
    run = Path(run_dir).resolve()
    stored = load(run/"scores.json")
    value = _compute_scores(run, write=False)
    for key in ("scope", "profiles", "comparisons", "unavailable_comparisons", "bootstrap", "stat_seed"):
        if stored[key] != value[key]:
            raise ValueError(f"Numerical replay disagrees with committed scores: {key}")
    return {"profiles_verified": len(value["profiles"]), "comparisons_verified": len(value["comparisons"]),
            "maximum_numeric_difference": 0.0, "read_only": True}
