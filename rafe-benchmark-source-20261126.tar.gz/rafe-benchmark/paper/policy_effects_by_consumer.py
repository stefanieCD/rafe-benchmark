"""Similarity and unique-record effects per consumer in the policy cohorts (post hoc, descriptive).

Reads frozen score files only; no inference, training, retrieval, calibration, or scoring is performed here.
The prespecified contrasts of cohorts A, B, D, E, F concern ROAR. The same contrasts for the other consumers
(and, for cohorts D, E, F, the age, copy and content contrasts of every consumer) were not declared: they are computed here from the per-cell errors already in the score files and carry no test.
For cohorts D, E, F the ROAR value equals the frozen prespecified estimate. For cohorts A and B the score files
hold per-cell errors already averaged over seeds and bank draws, so the value here differs slightly from the
frozen estimate (which averages log-ratios); the largest difference is recorded.

Usage: ../.venv/bin/python policy_effects_by_consumer.py   (writes policy_effects_by_consumer.json)
"""
from pathlib import Path
import hashlib
import json
import math

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
SRC = {'A': 'results/eab24/scores.json', 'B': 'results/eab26/scores.json', 'D': 'results/eab27/scores.json',
       'E': 'results/eab28/scores.json', 'F': 'results/eab29/scores.json'}
S = {k: json.loads((ROOT / p).read_text()) for k, p in SRC.items()}
METHODS = ['roar', 'crossrag', 'freshcast', 'freshcast_uniform']
FAMILIES = {'web': 'web_demand', 'load': 'grid_load', 'trading': 'market_activity'}
CONTRASTS = {'similarity': ('sim_high', 'sim_mid'), 'unique16': ('U16_unique', 'U16_slots'), 'age': ('age_old', 'age_recent'),
             'copies': ('dup5_concentrated', 'dup5_balanced'), 'content': ('dup10_unique', 'dup5_balanced')}

def from_cells(scores, a, b, fam, m):
    per = scores['per_family_series_period']
    logs = [math.log(v[m]['mse']) - math.log(per[b][fam][s][blk][m]['mse']) for s, blocks in per[a][fam].items() for blk, v in blocks.items()]
    return 100 * (1 - math.exp(sum(logs) / len(logs)))

def from_rho(rho, a, b, fam, m):
    return 100 * (1 - rho[a][m][fam] / rho[b][m][fam])

out = {}
for name, (a, b) in CONTRASTS.items():
    for short, fam in FAMILIES.items():
        row = {}
        for c in 'BDEF':
            if c == 'B':
                if fam not in S['B']['per_family_series_period'][a]:
                    continue
                row[c] = {m: from_cells(S['B'], a, b, fam, m) for m in METHODS}
            else:
                rho = S[c]['rho_by_family'] if c != 'F' else S[c]['rho_by_family']['bolt_base']
                row[c] = {m: from_rho(rho, a, b, fam, m) for m in METHODS}
        out[f'{name}_{short}'] = row
# Cohort A: unique versus row-wise top-10 over 16 records in 64 rows (web and taxi families).
A = S['A']['per_family_series_period']
for short, fam in [('web', 'web_demand'), ('taxi', 'taxi_mobility')]:
    out.setdefault(f'unique16_{short}', {})['A'] = {m: from_cells(S['A'], 'U16_N64_unique', 'U16_N64_slots', fam, m) for m in METHODS}

# The ROAR values must equal the frozen prespecified estimates.
checks = 0
approx = []
bp = {(r['family'], r['A']): r['improvement_percent'] for r in S['B']['primary']}
ua = {(r['family'], r['U']): r['improvement_percent'] for r in S['A']['primary_unique']}
for short, fam in FAMILIES.items():
    for c in 'DEF':
        H = S[c]['hypotheses'] if c != 'F' else S[c]['hypotheses']['bolt_base']
        for name, h in [('similarity', 'H3'), ('unique16', 'H2')]:
            assert abs(out[f'{name}_{short}'][c]['roar'] - H[h][fam]['improvement_percent']) < 5e-3, (c, name, fam)
            checks += 1
    if (fam, 'sim_high') in bp:
        approx.append(abs(out[f'similarity_{short}']['B']['roar'] - bp[(fam, 'sim_high')]))
for short, fam in [('web', 'web_demand'), ('taxi', 'taxi_mobility')]:
    approx.append(abs(out[f'unique16_{short}']['A']['roar'] - ua[(fam, 16)]))
assert len(approx) == 4 and max(approx) < 0.5, approx

# Default rolling memory: native-relative ratio of each consumer (below 1 is better than native Bolt).
rolling = {'A': {m: S['A']['aggregate']['rolling'][m]['native_relative_MSE_geomean'] for m in METHODS},
           'B': {m: S['B']['aggregate']['rolling'][m]['native_relative_MSE_geomean'] for m in METHODS},
           'D': {m: S['D']['rho']['rolling'][m] for m in METHODS}, 'E': {m: S['E']['rho']['rolling'][m] for m in METHODS},
           'F': {m: S['F']['rho']['bolt_base']['rolling'][m] for m in METHODS}}
rounded = {k: {c: {m: round(v, 2) for m, v in r.items()} for c, r in row.items()} for k, row in out.items()}
def span(key, m):
    v = [r[m] for r in rounded[key].values()]
    return [min(v), max(v)]
result = {
 'label': 'Post hoc, descriptive: contrasts for consumers other than ROAR were not prespecified and carry no test.',
 'metric': 'change of the native-relative geometric-mean MSE ratio, percent; positive favors the first policy of each contrast (high similarity; unique retrieval; old records; concentrated copies; ten unique records)',
 'sources_sha256': {k: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for k, p in SRC.items()},
 'roar_values_equal_to_frozen_estimates_DEF': checks,
 'largest_difference_from_frozen_roar_estimate_AB_points': round(max(approx), 2),
 'rolling_native_relative_ratio': {c: {m: round(v, 4) for m, v in r.items()} for c, r in rolling.items()},
 'effects': rounded,
 'ranges': {k: {m: span(k, m) for m in METHODS} for k in rounded},
}
(HERE / 'policy_effects_by_consumer.json').write_text(json.dumps(result, indent=1) + '\n')
print(json.dumps(result['ranges'], indent=1), checks)
