"""Generic scalar-series import and causal rolling/budget policy construction."""
from pathlib import Path
import csv
from datetime import datetime, timezone
import numpy as np
from .io import load, dump, resolve, protect_output

POLICIES = ["rolling", "U16_slots", "U16_unique", "U32_slots", "U32_unique",
            "dup5_balanced", "dup5_concentrated", "dup10_unique", "dup5_permuted"]

def shape(x):
    z = np.asarray(x, np.float32) - np.asarray(x, np.float32).mean(-1, keepdims=True)
    return z / np.sqrt((z*z).sum(-1, keepdims=True)).clip(1e-12)

class Series:
    def __init__(self, values, observed, start, context_length, horizon):
        self.values = np.asarray(values, np.float32)
        self.observed = np.asarray(observed, np.float32)
        self.start = int(start)
        self.L, self.H = int(context_length), int(horizon)
        if self.values.shape != self.observed.shape or self.values.ndim != 1:
            raise ValueError("Series values/observations must be matching 1D arrays")
        end = np.arange(self.L, len(self.values)-self.H+1)
        pv = np.r_[0, np.cumsum(~np.isfinite(self.values))]
        py = np.r_[0, np.cumsum(~np.isfinite(self.observed))]
        good = (pv[end]-pv[end-self.L] == 0) & (py[end+self.H]-py[end] == 0)
        self.ends = end[good] + self.start
        self.priority = {}
        self.selection_cache = {}

    def context(self, ends):
        ix = np.asarray(ends)-self.start
        return self.values[ix[:, None] + np.arange(-self.L, 0)]

    def record(self, ends, origin):
        ends = np.asarray(ends)
        if not np.all(ends+self.H <= origin):
            raise ValueError("Unavailable memory continuation")
        ix = ends-self.start
        return np.concatenate([self.context(ends), self.observed[ix[:, None]+np.arange(self.H)]], 1)

    def pool(self, origin, draw, series_index, recent_steps=2688, older_sample=500):
        if draw not in self.priority:
            self.priority[draw] = np.random.default_rng(draw+series_index*1009).random(len(self.ends))
        a = self.ends
        old = np.flatnonzero((a < origin-recent_steps) & (a+self.H <= origin))
        old = old[np.argsort(self.priority[draw][old], kind="stable")[:older_sample]]
        recent = a[(a >= origin-recent_steps) & (a+self.H <= origin)]
        return np.sort(np.r_[recent, a[old]])

def select_policy(series, origin, draw, series_index, row_index, policy, slots):
    if policy not in POLICIES:
        raise ValueError(f"Import a prepared bank or implement a policy plugin for {policy}")
    cache_key = (origin, draw, series_index, row_index)
    cached = series.selection_cache.get(cache_key)
    pool = cached[0] if cached else series.pool(origin, draw, series_index)
    if len(pool) < max(64, slots):
        raise ValueError("Insufficient eligible historical records")
    query = series.context(np.array([origin]))
    if cached:
        ranking = cached[1]
    else:
        similarity = (shape(query) @ shape(series.context(pool)).T)[0]
        ranking = pool[np.lexsort((pool, -similarity))]
        series.selection_cache[cache_key] = (pool, ranking)
    n = u = len(pool)
    if policy == "rolling":
        ends = ranking[:slots]
    elif policy.startswith(("U16", "U32")):
        u = 16 if policy.startswith("U16") else 32
        population = np.random.default_rng(draw+row_index*100003).permutation(pool)[:64][:u]
        sim = (shape(query) @ shape(series.context(population)).T)[0]
        ordered = population[np.lexsort((population, -sim))]
        n = 64
        if policy.endswith("unique"):
            if slots > u:
                raise ValueError("Unique retrieval requests more slots than records")
            ends = ordered[:slots]
        else:
            ends = np.repeat(ordered, 64//u)[:slots]
    else:
        if slots != 10:
            raise ValueError("Copy/content controls are defined at K=10")
        n = 10
        if policy == "dup10_unique":
            u, ends = 10, ranking[:10]
        elif policy == "dup5_concentrated":
            u, ends = 5, np.r_[np.repeat(ranking[0], 6), ranking[1:5]]
        else:
            u, ends = 5, np.repeat(ranking[:5], 2)
            if policy == "dup5_permuted":
                ends = np.random.default_rng(draw+row_index).permutation(ends)
    records = series.record(ends, origin)
    distance = (1-shape(query) @ shape(records[:, :series.L]).T)[0].clip(0, 2)
    return records, distance.astype(np.float32), ends, n, u

def read_series(config_path, entry):
    step = entry.get("step_seconds", 3600)
    if not isinstance(step, int) or isinstance(step, bool) or step < 1:
        raise ValueError("step_seconds must be a positive integer")
    path = resolve(config_path, entry["path"])
    if path.suffix == ".npz":
        with np.load(path, allow_pickle=False) as z:
            observed = z["observed"].copy() if "observed" in z else z["values"].copy()
            start = int(z["start_step"]) if "start_step" in z else int(z["start_hour"]) if "start_hour" in z else int(entry.get("start_step", entry.get("start_hour", 0)))
            if "step_seconds" in z and int(z["step_seconds"]) != step:
                raise ValueError("NPZ sampling interval disagrees with the manifest")
            return z["values"].copy(), observed, start
    if path.suffix != ".csv":
        raise ValueError("Series import supports .npz and .csv")
    with path.open(newline="") as f:
        rows = list(csv.DictReader(f))
    column = entry.get("value_column", "value")
    values = np.array([float(r[column]) if r[column].strip() else np.nan for r in rows], np.float32)
    if "time_column" in entry:
        times = [datetime.fromisoformat(r[entry["time_column"]].replace("Z", "+00:00")) for r in rows]
        if any(t.tzinfo is None for t in times):
            raise ValueError("CSV timestamps require an explicit timezone")
        seconds = np.array([t.timestamp() for t in times])
        if not len(seconds) or not np.all(np.diff(seconds) == step):
            label = "hourly" if step == 3600 else f"{step}-second"
            raise ValueError(f"CSV timestamps must form a regular {label} series")
        start = int(np.floor(seconds[0]/step))
    else:
        start = int(entry.get("start_hour", 0))
    return values, values.copy(), start

def prepare(manifest_path, out_dir):
    spec = load(manifest_path)
    out = protect_output(out_dir)
    if out.exists() and any(out.iterdir()):
        raise FileExistsError("Preparation requires a new empty directory")
    out.mkdir(parents=True, exist_ok=True)
    horizon, length = int(spec["H"]), int(spec["L"])
    step = spec.get("step_seconds", 3600)
    if not isinstance(step, int) or isinstance(step, bool) or step < 1:
        raise ValueError("step_seconds must be a positive integer")
    contexts, targets, series_ids, families, blocks, origins = [], [], [], [], [], []
    corpora = []
    for si, entry in enumerate(spec["series"]):
        if entry.get("step_seconds", step) != step:
            raise ValueError("A workload requires a common sampling interval")
        values, observed, start = read_series(manifest_path, {**entry, "step_seconds": step})
        corpora.append(Series(values, observed, start, length, horizon))
        offsets, labels = entry["query_indices"], entry["block_indices"]
        if len(offsets) != len(labels):
            raise ValueError("Each query requires a temporal block")
        for offset, block in zip(offsets, labels):
            if offset < length or offset+horizon > len(values):
                raise ValueError("Query exceeds the series boundaries")
            x, y = values[offset-length:offset], observed[offset:offset+horizon]
            if not np.isfinite(x).all() or not np.isfinite(y).any():
                raise ValueError("Invalid context or target without observed values")
            contexts.append(x); targets.append(y); series_ids.append(si)
            families.append(entry["family"]); blocks.append(block); origins.append(start+offset)
    query = dict(context=np.asarray(contexts, np.float32), series=np.asarray(series_ids),
                 family=np.asarray(families), block=np.asarray(blocks), origin=np.asarray(origins), step_seconds=np.array(step))
    np.savez(out/"queries.npz", **query)
    np.savez(out/"targets.npz", target=np.asarray(targets, np.float32))
    cases = []
    for draw in spec["draws"]:
        for policy in spec["policies"]:
            rows, distances, ends, ns, us = [], [], [], [], []
            for i, (si, origin) in enumerate(zip(series_ids, origins)):
                r, d, e, n, u = select_policy(corpora[si], origin, int(draw), si, i, policy, int(spec["K"]))
                rows.append(r); distances.append(d); ends.append(e); ns.append(n); us.append(u)
            bank = out/f"bank_{draw}_{policy}.npz"
            np.savez(bank, records=np.asarray(rows), distance=np.asarray(distances), record_end=np.asarray(ends),
                     record_series=np.broadcast_to(query["series"][:, None], (len(query["series"]), spec["K"])),
                     N=np.asarray(ns), U=np.asarray(us))
            cases.append({"id": f"{spec['cohort']}_{draw}_{policy}", "cohort": spec["cohort"],
                          "suite": spec.get("suite", "main"), "policy": policy, "draw": draw,
                          "H": horizon, "K": int(spec["K"]), "step_seconds": step, "queries": str(out/"queries.npz"),
                          "bank": str(bank), "targets": str(out/"targets.npz")})
    dump(out/"prepared_cases.json", cases)
    dump(out/"source_manifest.json", spec)
    return {"cases_file": str(out/"prepared_cases.json"), "queries": len(contexts), "cases": len(cases)}

def demo(out_dir):
    out = protect_output(out_dir)
    if out.exists() and any(out.iterdir()):
        raise FileExistsError("Demo requires a new empty directory")
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(1415)
    entries = []
    indices = [400+40*b+j*8 for b in range(12) for j in range(2)]
    labels = [b for b in range(12) for j in range(2)]
    for si in range(3):
        x = np.sin(np.arange(1000)/12+si) + .001*np.arange(1000) + rng.normal(0, .02, 1000)
        path = out/f"series{si}.npz"
        np.savez(path, values=x.astype(np.float32), start_hour=0)
        entries.append(dict(path=str(path), name=f"series{si}", family="synthetic",
                            query_indices=indices, block_indices=labels))
    manifest = {"L": 32, "H": 8, "K": 3, "cohort": "demo", "series": entries,
                "policies": ["rolling", "U16_slots", "U16_unique"], "draws": [11, 12, 13]}
    dump(out/"data.json", manifest)
    result = prepare(out/"data.json", out/"prepared")
    config = {"format_version": 1, "scope": "synthetic", "bootstrap": 1000,
              "plugins": [{"factory": "rafe.toy:Persistence", "outputs": ["persistence"]},
                          {"factory": "rafe.toy:MemoryMean", "outputs": ["memory"]}],
              "cases": load(result["cases_file"]), "baselines": {"memory": "persistence"},
              "policy_contrasts": [["U16_unique", "U16_slots"]], "rank_pairs": [["memory", "persistence"]]}
    dump(out/"config.json", config)
    return {"config": str(out/"config.json"), **result}
