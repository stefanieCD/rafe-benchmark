# RAFE

**RAFE**（Retrieval-Augmented Forecasting Evaluation）是面向检索增强时间序列预测的记忆感知评测基准。它把「预测方法 + 检索记忆」作为一等实验对象，在冻结预测器的条件下，用受控记忆政策比较相似度、记忆年龄、重复记录和唯一内容规模，并显式报告物理行数、唯一记录数、返回槽位数和权重集中度。

本仓库是 VLDB 2027 / PVLDB Volume 20 Experiment, Analysis & Benchmark 稿件
《RAFE: A Memory-Aware Evaluation Framework for Retrieval-Augmented Time Series Forecasting》
的源码工件。发布版本为 **rafe-eval 0.2.0**。研究工作区根目录的 `pyproject.toml` 仍写着 0.1.0，本仓库未采用该文件，也不得用 0.1.0 覆盖 0.2.0 源码。

## 安装与可验证示例

需要 Python 3.10+ 与 NumPy：

```sh
python -m venv .venv
source .venv/bin/activate
python -m pip install -e .
# 或：python -m pip install dist/rafe_eval-0.2.0-py3-none-any.whl

rafe demo --out demo_data
rafe freeze demo_data/config.json --run-dir demo_run
rafe predict --run-dir demo_run
rafe score --run-dir demo_run
rafe report --run-dir demo_run
rafe verify --run-dir demo_run
rafe replay --run-dir demo_run
```

该示例使用三条合成序列和两个无额外依赖的插件，只验证工具流程，不能作为论文的实证结果。在组装环境中，回放的最大数值差为 0.0。

更完整的插件接口与记忆导入说明见 `rafe/README.md`。

## 论文源稿与 PDF

权威源稿是 `paper/source/parts/`（`00_preamble.tex` 至 `10_closing_references.tex`）。合并稿 `paper/main.tex` 与分节源稿字节级一致。摘要为 201 词。活动图 5 张、活动表 9 张。`paper/main.pdf`（13 页）已由上述最新源稿重新编译；磁盘上更早的 `source/build/main.pdf`（2026-11-25 15:00，台北时间）早于摘要修订（同日 16:57），以最新源稿为准。

## 已验证范围

本仓库可核验：0.2.0 源码与包元数据、分节稿可精确拼出 `main.tex`、PDF 可成功编译，以及上述合成示例。作者先前交付记录中的完整政策扩展（队列 B/D/E/F，十三项记忆政策）和多频率推广（队列 J/K 等）依赖更大的可迁移包，不在本精简树中。本仓库不包含基础模型权重与作者检查点，也不声称已完整复现论文全部实验、已完成第三方人工复现，或跨硬件逐位一致。检索扩展性耗时记录在 `paper/retrieval_scaling_results.json`，重跑需要论文 method-14 输入且墙钟时间不可逐位复现。

数据来源于公开 standard-seven 基准以及作者收集的十个新队列（A、B、D–K）；本树不重发序列、记忆库或已提交预测。许可尚未选定，见 `NOTICE`。
