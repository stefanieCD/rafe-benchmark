"""Tables for the fresh-data transfer study (cohorts G, H, I and the memory-construction control).

Reads frozen score files only; no inference, training, retrieval, calibration, or scoring is performed here.
Run after build_assets.py: this script owns tables/data.tex and tables/prior.tex (extended versions) and writes
tables/{standard,fresh,family,memory}.tex plus fresh_numbers.json (every number quoted in the prose of the transfer study and the memory control).

Usage (from this directory): ../.venv/bin/python build_fresh_tables.py
"""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
TABLES = HERE / 'tables'
load = lambda p: json.loads((ROOT / p).read_text())
SOURCES = {
 'G': 'results/eab30/scores.json', 'H': 'results/eab31/scores.json', 'I': 'results/eab32/scores.json',
 'G_alignrag_post_hoc': 'tmp/eab31_dry/cohortG_scores.json', 'memory_control': 'results/eab33/scores.json',
 'standard_local': 'results/method7/paired.json', 'standard_alignrag': 'results/method10/alignrag/scores.json',
 'cost': 'results/eab31/cost.json', 'published': 'manuscript_en/published_numbers.json',
 'G_selection': 'results/eab30/selection.json', 'H_selection': 'results/eab31/selection.json', 'I_selection': 'results/eab32/selection.json',
 'tsrag_authors_plan': 'results/method11/analysis_plan.json', 'tsrag_authors_commit': 'results/method11/prediction_commit.json',
 'tsrag_authors_standard': 'results/method11/scores.json', 'tsrag_authors_G': 'results/method11/freshbench_G.json',
 'tsrag_authors_H': 'results/method11/freshbench_H.json', 'tsrag_authors_I': 'results/method11/freshbench_I.json',
 'characteristics': 'results/method13/characteristics.json', 'characteristics_plan': 'results/method13/analysis_plan.json',
 'training_cost': 'results/method9/cost.json',
 'released_plan': 'results/method12/analysis_plan.json', 'released_commit': 'results/method12/prediction_commit.json',
 'released_scores': 'results/method12/scores.json', 'released_summary': 'results/method12/summary.json'}
G, H, I = load(SOURCES['G']), load(SOURCES['H']), load(SOURCES['I'])
GP, E = load(SOURCES['G_alignrag_post_hoc']), load(SOURCES['memory_control'])
M7, M10, COST = load(SOURCES['standard_local']), load(SOURCES['standard_alignrag']), load(SOURCES['cost'])
assert 'post hoc development observation' in GP['note']
PUB = load(SOURCES['published'])
# Post hoc row: the authors' public TS-RAG checkpoint (results/method11; one checkpoint, one pass, scored once after all other rows).
A11 = load(SOURCES['tsrag_authors_standard'])
AF = {c: load(SOURCES['tsrag_authors_' + c]) for c in 'GHI'}
APLAN = load(SOURCES['tsrag_authors_plan'])
sha_of = lambda k: hashlib.sha256((ROOT / SOURCES[k]).read_bytes()).hexdigest()
assert A11['post_hoc'] is True and A11['label'].startswith('POST HOC') and APLAN['status'].startswith('POST HOC')
assert A11['analysis_plan_sha256'] == sha_of('tsrag_authors_plan') and A11['prediction_commit_sha256'] == sha_of('tsrag_authors_commit')
assert load(SOURCES['tsrag_authors_commit'])['targets_read'] is False
for c, S in zip('GHI', (G, H, I)):
    assert AF[c]['method'] == 'tsrag_authors_checkpoint' and AF[c]['cohort'] == c and AF[c]['queries'] == S['queries'] and 'scored once' in AF[c]['not_blind']
# Post hoc, descriptive characteristics of the series (results/method13; inputs only, computed once) and recorded training cost.
CH, CHPLAN, TC = load(SOURCES['characteristics']), load(SOURCES['characteristics_plan']), load(SOURCES['training_cost'])
assert CH['descriptive'] is True and CH['post_hoc'] is True and CH['targets_read'] is False and CH['forecasts_read'] is False
assert CH['plan_written_at_utc'] == CHPLAN['written_at_utc'] < CH['computed_at_utc'] and CHPLAN['status'].startswith('DESCRIPTIVE AND POST HOC')
AUTHORS = r"TS-RAG (authors)$^\ddagger$"
AUTHORS_SHORT = r"TS-RAG$^\ddagger$"

# Methods published at a main conference first, then the workshop paper, the preprints, and our two blends.
METHODS = ['tsrag', 'raf', 'pfrp', 'alignrag', 'crossrag', 'roar', 'ratl', 'static_native', 'context_native']
NAME = {'native': 'Native Bolt', 'roar': 'ROAR', 'crossrag': 'Cross-RAG', 'tsrag': 'TS-RAG', 'pfrp': 'PFRP', 'ratl': 'RATL',
        'raf': 'RAF', 'alignrag': 'Align-RAG', 'static_native': 'Constant blend', 'context_native': 'Context blend',
        'transport_native': 'Feedback blend'}
KIND = {'roar': 'trained', 'crossrag': 'trained', 'tsrag': 'trained', 'pfrp': 'trained', 'ratl': 'trained',
        'raf': 'training-free', 'alignrag': 'training-free', 'static_native': 'source-fitted', 'context_native': 'source-fitted'}
VENUE = {'tsrag': "NeurIPS'25", 'raf': "AISTATS'26", 'pfrp': "AAAI'26", 'alignrag': "NeurIPS'26", 'crossrag': "KDD-W'26",
         'roar': 'preprint', 'ratl': 'preprint', 'static_native': 'ours', 'context_native': 'ours'}
TAG = {'trained': 'T', 'training-free': 'F', 'source-fitted': 'S'}
def source(m):
    return f'{VENUE[m]} ({TAG[KIND[m]]})'

def pct(x):
    return '0.00' if abs(x) < .005 else f'{x:+.2f}'

def ci(c):
    return f'[{c[0]:+.2f}, {c[1]:+.2f}]'

def pv(p):
    return '1.00' if p > .995 else (f'{p:.4f}' if p < .01 else f'{p:.3f}').lstrip('0')

def write_table(name, caption, headers, rows, spec, wide=True, note='', font=None, extra_header=''):
    env = 'table*' if wide else 'table'
    width = r'\textwidth' if wide else r'\columnwidth'
    font = font or (r'\small' if wide else r'\footnotesize')
    flexible = 'Y' in spec or 'X' in spec
    begin_tab = rf'\begin{{tabularx}}{{{width}}}{{{spec}}}' if flexible else rf'\begin{{tabular}}{{{spec}}}'
    end_tab = r'\end{tabularx}' if flexible else r'\end{tabular}'
    text = [rf'\begin{{{env}}}[t]', r'\centering',
            rf'\caption{{{caption}}}', rf'\label{{tab:{name}}}', font,
            begin_tab, r'\toprule']
    if extra_header:
        text += [extra_header]
    text += [' & '.join(headers) + r' \\', r'\midrule']
    text += [' & '.join(row) + r' \\' for row in rows]
    text += [r'\bottomrule', end_tab]
    if note:
        text += [r'\par\smallskip', r'\begin{minipage}{'+width+'}'+r'\footnotesize '+note+r'\end{minipage}']
    text += [rf'\end{{{env}}}', '']
    (TABLES / f'{name}.tex').write_text('\n'.join(text))

# ---------------------------------------------------------------- workloads and prior work (extended)
data = [
 ['Standard seven', 'ETTh1/2, ETTm1/2, Weather, Electricity, Exchange', 'Public splits', '2,099,701', 'Benchmark; memory control'],
 ['Cohort A', 'Web de/ja; green-taxi pickups (total, credit card)', 'Apr. 2025', '432', 'Policy: unique $K$, budget'],
 ['Cohort B', 'Web fr/es; load NO/SE', 'Jan. 2025', '432', 'Policy: matched contrasts'],
 ['Cohort D', 'Web it/pl/nl/sv; load HU/RO/HR/BG; trading AVAX/LINK/DOT/TRX', 'Mar. 2025', '1,296', 'Policy: replication'],
 ['Cohort E', 'Web pt/cs/tr/fi; load SK/LT/LV/EE; trading ATOM/NEAR/ETC/BCH', 'Mar. 2025', '1,292', 'Policy; test of CMB'],
 ['Cohort F', 'Web ko/id/uk/he; load RS/LU; trading UNI/AAVE/XLM/FIL', 'Mar. 2025', '1,080', 'Second backbone'],
 ['Cohort G', 'Web ru/zh/fa/hu; load PL/CZ/XK; trading HBAR/ICP/XTZ/SAND', 'Mar. 1, 2025', f"{G['queries']:,}", 'Transfer; context blend'],
 ['Cohort H', 'Web: 16 editions; trading: 16 assets; load: 7 countries', 'Mar. 23, 2025', f"{H['queries']:,}", 'Transfer; predictions'],
 ['Cohort I', 'NOAA stations: 12 temperature, 12 humidity, 10 wind speed, 12 altimeter', 'Mar. 23, 2025', f"{I['queries']:,}", 'Transfer; gap rule'],
 ['Backbone check', 'Load AT/CH; trading LTC/DOGE', 'Apr. 2025', '320', 'Six blocks; side checks']]
assert len(G['series']) == 11 and len(H['series']) == 39 and len(I['series']) == 46
chosen = load(SOURCES['I_selection'])['chosen']
assert [len(chosen[f]) for f in ['temperature', 'relative_humidity', 'wind_speed', 'altimeter']] == [12, 12, 10, 12]
hsel = load(SOURCES['H_selection'])
assert hsel['dropped_families'] == ['meteorology'] and [len(hsel['chosen'][f]) for f in ['web_demand', 'market_activity', 'grid_load']] == [16, 16, 7]
assert sum(E['queries'].values()) == 28044
write_table('data', 'Workloads and their roles (twelve 14-day blocks per cohort, one every 44 days; queries counted without seed and bank-draw replication). Web: Wikipedia page views per language edition; load: national electricity load; trading: exchange trade counts',
 ['Workload', 'Target series', 'First block', 'Queries', 'Role'], data,
 r'@{}lYlrl@{}', font=r'\footnotesize')

prior = [
 [r'ROAR~\cite{roar}', 'Similarity/utility mismatch; alignment, gates, identities', 'Content versus record-weight mass; learnability of slot allocation; transfer to post-freeze series'],
 [r'Cross-RAG~\cite{crossrag}', r'$K$, random retrieval, bank fraction/source', 'Paired absolute budgets and availability'],
 [r'FreshCast~\cite{freshcast}', 'Rolling access, complementarity, prefix calibration', 'Matched age; original-budget anchor limits'],
 [r'SARAF~\cite{saraf}', 'Nonstationarity, redundancy, diversity', 'Fixed-content copies versus content expansion'],
 [r'PRR~\cite{prr}', 'Fixed support/budget; relevance versus utility', 'Joint record-identity, age, and access audit'],
 [r'CASP-LLM~\cite{casp}', 'Cross-batch prompt-pool concentration', 'Within-query replication of raw histories'],
 [r'Retrieval-regime audit~\cite{regime}', 'For trained backbones on standard benchmarks, the retrieval gain depends on the window-to-period operating point', 'Frozen foundation model; series acquired after freezing; written predictions; memory-construction control'],
 [r'Delay-aware TTA audit~\cite{delay}', 'Label delay; leaky test-time updates inflate gains', 'As-of-origin banks and matured labels for retrieval memory'],
 [r'TFB/GIFT-Eval/TIME~\cite{tfb,gifteval,timebench}', 'Unified, broad, leakage-aware forecasting evaluation', 'Executable memory and time/budget contract; retrieval-specific fresh cohorts']]
write_table('prior', 'What prior work establishes and what this study adds',
 ['Prior work', 'Established', 'This study adds'], prior, r'@{}p{0.17\textwidth}YY@{}', font=r'\footnotesize')

YES, NO = r'\checkmark', '--'
position = [
 [r'TFB~\cite{tfb}', 'Statistical, ML, deep forecasters', NO, NO, NO],
 [r'GIFT-Eval~\cite{gifteval}', 'Foundation models and baselines', NO, NO, NO],
 [r'TIME~\cite{timebench}', 'Foundation models, zero-shot', YES, NO, NO],
 [r'Regime audit~\cite{regime}', 'Retrieval plug-ins, trained models', NO, NO, NO],
 [r'Delay audit~\cite{delay}', 'Test-time adaptation methods', NO, NO, NO],
 ['This study', 'Retrieval adapters, frozen models', YES, YES, YES]]
write_table('position', 'This study next to forecasting benchmarks and audits',
 ['Study', 'Methods evaluated', 'Fresh', 'Pred.', 'Mem.'], position, r'@{}lYccc@{}', wide=False,
 note=r'Fresh: unseen evaluation datasets (TIME: chosen to avoid pretraining leakage; here: acquired after models and tests were frozen, without a pretraining-exclusion guarantee). Pred.: expected outcomes written before acquisition. Mem.: retrieval memory varied at a fixed consumer. --: not part of the study as its paper describes it.')

# ---------------------------------------------------------------- standard seven: local runs next to published numbers
agg, pub = M7['aggregate'], M7['contrasts']['context_native']
assert M7['published_source'].startswith('ROAR author manuscript, Tables 1-2')
PV = PUB['values']
for k, v in PUB['per_dataset_mse'].items():
    assert k == 'order' or abs(sum(v) / 7 - PV[k]['mse']) < 6e-5, k
def published(m):
    """Published macro MSE, MAE and the paper they are taken from: the method's own paper where it reports this setting."""
    if m in PV:
        v = PV[m]
        return f"{v['mse']:.4f}", ('--' if v['mae'] is None else f"{v['mae']:.4f}"), rf"\cite{{{v['paper']}}}", v['mse']
    if m == 'alignrag':
        v = M10['macro']['published_alignrag']
        return f"{v['mse']:.4f}", f"{v['mae']:.4f}", r'\cite{alignrag}', v['mse']
    if m in pub:
        return f"{pub[m]['published_macro_mse']:.3f}", f"{pub[m]['published_macro_mae']:.3f}", r'\cite{roar}', pub[m]['published_macro_mse']
    return '--', '--', '--', None
def local(m):
    if m == 'alignrag':
        return M10['macro']['alignrag']['mse'], M10['macro']['alignrag']['mae']
    return agg[m]['macro_mse_mean'], agg[m]['macro_mae_mean']
# Cost columns: trainable neural parameters (results/method9/cost.json; identical for the five seeds) and inference latency
# relative to native Bolt (results/eab31/cost.json; batch of 16, retrieval search and I/O excluded). Nothing is measured here.
PARAMS = TC['source_trainable_neural_parameters']
assert all(PARAMS[s] == PARAMS['2021'] for s in PARAMS) and len(PARAMS) == 5
COST_KEY = {'ratl': 'ratl_cached_support'}
def params(m):
    if m in PARAMS['2021']:
        n = PARAMS['2021'][m]
    else:  # Align-RAG is training-free; the feedback blend, like the context blend, has tree controllers and no neural parameter
        assert m in ('alignrag', 'transport_native')
        n = 0
    return '0' if n == 0 else f'{n / 1e6:.2f}'
def latency(m):
    return f"{COST['aggregate'][COST_KEY.get(m, m)]['latency_ratio_to_native']:.2f}"
def std_row(m):
    mse, mae, src, _ = published(m)
    return [NAME[m], src, mse, mae, f'{local(m)[0]:.4f}', f'{local(m)[1]:.4f}', params(m), latency(m)]
assert abs(M10['macro']['native']['mse'] - agg['native']['macro_mse_mean']) < 1e-6
STD_ORDER = ['native'] + METHODS + ['transport_native']
standard_rows = [std_row(m) for m in STD_ORDER]
standard_numbers = {r[0]: r[2:] for r in standard_rows}
assert abs(A11['macro']['native_mse'] - agg['native']['macro_mse_mean']) < 1e-6 and abs(A11['macro']['local_tsrag_mse_mean_of_5'] - agg['tsrag']['macro_mse_mean']) < 1e-6
authors_std = [AUTHORS, published('tsrag')[2], published('tsrag')[0], published('tsrag')[1], f"{A11['macro']['mse']:.4f}", f"{A11['macro']['mae']:.4f}", '--', '--']
standard_numbers['TS-RAG (authors checkpoint, post hoc)'] = authors_std[2:]
standard_rows.insert(STD_ORDER.index('tsrag') + 1, authors_std)
write_table('standard', 'Standard seven: published and local macro errors of all methods, and their cost',
 ['Method', 'From', 'MSE', 'MAE', 'MSE', 'MAE', 'Par.', 'Time'], standard_rows, '@{}lcrrrrrr@{}', wide=False,
 font=r'\footnotesize\setlength{\tabcolsep}{3.6pt}',
 extra_header=r' & \multicolumn{3}{c}{Published} & \multicolumn{2}{c}{Local run} & \multicolumn{2}{c}{Cost} \\ \cmidrule(lr){2-4}\cmidrule(lr){5-6}\cmidrule(l){7-8}',
 note=r'Published: from the cited paper (context 512, horizon 64, Chronos-Bolt); Cross-RAG: its $K=10$ ablation (MSE only; 0.191/0.252 at its default $K=15$); PFRP and RATL: the zero-shot adaptations of~\cite{roar}. Local: mean of five seeds (RAF, Align-RAG: deterministic); trained heads are trained by us. $^\ddagger$Post hoc: the public checkpoint of the TS-RAG authors (architecture of the TS-RAG row), run once after all other rows had been scored. The blends are ours, developed on this benchmark. Par.: trainable parameters (millions). Time: inference time relative to native Bolt (batch 16; retrieval search and I/O excluded); RATL with stored native forecasts (' + f"{COST['aggregate']['ratl_live_support']['latency_ratio_to_native']:.2f}" + r' if computed per query).')
def gap(m):
    """Local macro MSE relative to the published value, percent (positive: local error is higher)."""
    return round(100 * (local(m)[0] / published(m)[3] - 1), 2)

# ---------------------------------------------------------------- written predictions, evaluated mechanically
def verdicts(cohort):
    """True = the written prediction held. Ranges are those of repro/eab31_protocol.json and repro/eab32_protocol.json."""
    S = H if cohort == 'H' else I
    r = {m: S['hypotheses']['H1'][m]['pooled'] for m in METHODS}
    g = {m: r[m]['improvement_percent'] for m in METHODS}
    better = {m: g[m] > 0 and r[m]['Holm9_p'] < .05 for m in METHODS}
    worse = {m: g[m] < 0 and r[m]['Holm9_p'] < .05 for m in METHODS}
    neither = {m: not better[m] and not worse[m] for m in METHODS}
    if cohort == 'H':
        return {'static_native': better['static_native'] and .2 <= g['static_native'] <= .7,
                'roar': neither['roar'] and abs(g['roar']) <= 2, 'tsrag': neither['tsrag'] and abs(g['tsrag']) <= 2,
                'context_native': neither['context_native'] and abs(g['context_native']) <= 2,
                'crossrag': worse['crossrag'] and -4 <= g['crossrag'] <= -1, 'ratl': g['ratl'] < 0,
                'raf': worse['raf'] and g['raf'] < -5, 'pfrp': worse['pfrp'] and g['pfrp'] < -5,
                'alignrag': 0 <= g['alignrag'] <= 4}
    return {'static_native': better['static_native'] and .1 <= g['static_native'] <= .7,
            'roar': neither['roar'] and abs(g['roar']) <= 2.5, 'tsrag': neither['tsrag'] and abs(g['tsrag']) <= 2,
            'crossrag': -3 <= g['crossrag'] <= -.5, 'context_native': -3 <= g['context_native'] <= 0,
            'ratl': -6 <= g['ratl'] <= -1, 'raf': worse['raf'] and g['raf'] < -4, 'pfrp': worse['pfrp'] and g['pfrp'] < -4,
            'alignrag': (not better['alignrag']) and -5 <= g['alignrag'] <= 1}
HELD = {'H': verdicts('H'), 'I': verdicts('I')}

# ---------------------------------------------------------------- cohorts G, H, I: nine methods versus native
def g_entry(m):
    if m == 'alignrag':
        return GP['H1'][m]['pooled'], GP['H1'][m]['MAE'], GP['H1'][m]['family'], True
    v = G['secondary']['versus_native'][m]
    return v['pooled'], v['pooled_MAE'], v['family'], False
def hi_entry(S, m):
    h = S['hypotheses']['H1'][m]
    return h['pooled'], h['pooled_MAE'], h['family']

fresh_rows = []
for m in METHODS:
    gp, gm, _, post = g_entry(m)
    row = [NAME[m], source(m), pct(gp['improvement_percent']) + (r'$^\dagger$' if post else '') + ' ' + ci(gp['CI95']), pv(gp['p']), pct(gm['improvement_percent'])]
    for c, S in [('H', H), ('I', I)]:
        p, mae, _ = hi_entry(S, m)
        est = pct(p['improvement_percent'])
        if p['Holm9_p'] < .05:
            est = r'\textbf{' + est + '}'
        row += [est + ' ' + ci(p['CI95']) + ('' if HELD[c][m] else r'$^\times$'), pv(p['Holm9_p']), pct(mae['improvement_percent'])]
    fresh_rows.append(row)
# Post hoc row (no Holm correction, no written per-method prediction, never bold): unadjusted p in every cohort.
authors_fresh = [AUTHORS_SHORT, "NeurIPS'25 (A)"]
for c in 'GHI':
    v = AF[c]['versus_native']
    authors_fresh += [pct(v['pooled']['improvement_percent']) + ' ' + ci(v['pooled']['CI95']), pv(v['pooled']['p']), pct(v['pooled_MAE']['improvement_percent'])]
fresh_rows.insert(METHODS.index('tsrag') + 1, authors_fresh)
write_table('fresh', r'Nine retrieval methods and one post hoc row against native Chronos-Bolt on three cohorts acquired after freezing (reduction of native-relative error, \%; positive is better than native)',
 ['Method', 'Source', r'MSE [95\% interval]', '$p$', 'MAE', r'MSE [95\% interval]', 'Holm $p$', 'MAE', r'MSE [95\% interval]', 'Holm $p$', 'MAE'],
 fresh_rows, r'@{}ll@{\hspace{5pt}}r@{\hspace{4pt}}r@{\hspace{4pt}}r@{\hspace{8pt}}r@{\hspace{4pt}}r@{\hspace{4pt}}r@{\hspace{8pt}}r@{\hspace{4pt}}r@{\hspace{4pt}}r@{}', font=r'\footnotesize',
 extra_header=rf" & & \multicolumn{{3}}{{c}}{{Cohort G: {len(G['series'])} series, {G['queries']:,} queries}} & \multicolumn{{3}}{{c}}{{Cohort H: {len(H['series'])} series, {H['queries']:,} queries}} & \multicolumn{{3}}{{c}}{{Cohort I: {len(I['series'])} series, {I['queries']:,} queries}} \\ \cmidrule(lr){{3-5}}\cmidrule(lr){{6-8}}\cmidrule(l){{9-11}}",
 note=r'Equal-series, equal-block log-ratio estimates over five seeds $\times$ five bank draws; crossed bootstrap intervals; exact sign-flip tests over twelve blocks. Cohorts H and I: Holm over the nine tests, bold when Holm $p<0.05$; $^\times$ marks a written prediction that failed. Cohort G: unadjusted $p$ (its declared tests are in the text). $^\dagger$Post hoc development observation: Align-RAG was run on cohort G after its scoring. MAE: the same estimate on absolute errors. Source: venue (KDD-W: KDD workshop); T trained head (trained by us), F training-free, S blend fitted on source series, A public checkpoint of the authors. $^\ddagger$Post hoc row, run once after all cohorts had been scored (one set of weights $\times$ five bank draws): unadjusted $p$ in every cohort, never bold, no written prediction per method.')

# ---------------------------------------------------------------- per-family view
FAMS = [('G', 'web_demand', 'Web'), ('G', 'grid_load', 'Load'), ('G', 'market_activity', 'Trading'),
        ('H', 'web_demand', 'Web'), ('H', 'grid_load', 'Load'), ('H', 'market_activity', 'Trading'),
        ('I', 'temperature', 'Temp.'), ('I', 'relative_humidity', 'Humid.'), ('I', 'wind_speed', 'Wind'), ('I', 'altimeter', 'Altim.')]
def fam(c, f, m):
    if c == 'G':
        return g_entry(m)[2][f]
    return hi_entry(H if c == 'H' else I, m)[2][f]
def fam_n(c, f):
    return len(fam(c, f, 'roar')['series'])
family_rows = []
for m in METHODS:
    row = [NAME[m]]
    for c, f, _ in FAMS:
        x = fam(c, f, m)
        cell = pct(x['improvement_percent'])
        if c == 'I' and x['Holm9_p'] < .05:
            cell = r'\textbf{' + cell + '}'
        if c == 'G' and m == 'alignrag':
            cell += r'$^\dagger$'
        row.append(cell)
    family_rows.append(row)
family_rows.insert(METHODS.index('tsrag') + 1, [AUTHORS_SHORT] + [pct(AF[c]['versus_native']['family'][f]['improvement_percent']) for c, f, _ in FAMS])
CHROWS = [('Seasonality', 'seasonal_strength'), ('Trend', 'trend_strength'), ('Record dist.', 'nearest_record_distance')]
for i, (label, key) in enumerate(CHROWS):
    family_rows.append([('\\midrule\n' if i == 0 else '') + label] + [f"{CH['cohorts'][c]['families'][f][key]['median']:.2f}" for c, f, _ in FAMS])
for c, f, _ in FAMS:
    assert CH['cohorts'][c]['families'][f]['series'] == fam_n(c, f)
write_table('family', r'The same contrasts by data family (reduction of native-relative MSE, \%), and characteristics of the families',
 ['Method'] + [f'{label} ({fam_n(c, f)})' for c, f, label in FAMS], family_rows, '@{}l' + 'r' * 10 + '@{}', font=r'\footnotesize',
 extra_header=r' & \multicolumn{3}{c}{Cohort G} & \multicolumn{3}{c}{Cohort H} & \multicolumn{4}{c}{Cohort I (station series)} \\ \cmidrule(lr){2-4}\cmidrule(lr){5-7}\cmidrule(l){8-11}',
 note=r'Number of series in parentheses. Cohort I: bold when the family-level Holm $p$ over the nine methods is below 0.05; the frozen files of cohorts G and H carry no family-level multiplicity correction, so their cells are descriptive. $^\dagger$Post hoc development observation. $^\ddagger$TS-RAG with the public checkpoint of its authors, post hoc; no multiplicity correction, never bold. Last three rows (post hoc, descriptive, from model inputs only): family medians of the daily seasonal strength and the trend strength of the series before its first query, and of the shape distance of the nearest retrieved record.')

# ---------------------------------------------------------------- memory-construction control on the standard seven
assert E['label'].startswith('Diagnostic on an already-observed benchmark')
memory_rows = []
for m in METHODS:
    g = {c: E['gain_over_native'][c][m]['vs_native'] for c in ['released', 'shape_train', 'shape_rolling']}
    d = E['primary_rolling_minus_released'][m]
    diff = pct(d['improvement_percent'])
    if d['Holm9_p'] < .05:
        diff = r'\textbf{' + diff + '}'
    memory_rows.append([NAME[m]] + [pct(g[c]['improvement_percent']) for c in g] + [f"{g['shape_rolling']['datasets_improved']}/7", diff, pv(d['Holm9_p'])])
write_table('memory', r'Memory control on the standard seven (gain over native, \%)',
 ['Method', 'Released', 'Train', 'Rolling', 'Sets', r'$\Delta$', 'Holm $p$'], memory_rows, '@{}lrrrrrr@{}', wide=False,
 note=r'Released: the published retrieval table (encoder embeddings, train-split records). Train: the same candidates ranked by shape distance. Rolling: the cohort rule. Sets: datasets with a gain under rolling memory. $\Delta$: rolling minus released (primary contrast; bold when Holm $p<0.05$). Diagnostic on an observed benchmark, 28,044 sampled queries, one bank draw.')

# ---------------------------------------------------------------- numbers quoted in the prose
def short(x):
    return {'gain': round(x['improvement_percent'], 2), 'ci': [round(v, 2) for v in x['CI95']], 'p': round(x['p'], 4),
            **{k: round(x[k], 4) for k in ['Holm9_p', 'Holm5_p', 'Holm6_p'] if k in x},
            **{k: x[k] for k in ['blocks_improved', 'series_improved', 'datasets_improved'] if k in x}}
def authors_cohort(c):
    v = AF[c]['versus_native']
    return {'versus_native': short(v['pooled']), 'p6': v['pooled']['p6'], 'bonferroni10_p': round(min(1., 10 * v['pooled']['p']), 4),
            'MAE': short(v['pooled_MAE']), 'equal_family': round(v['equal_family']['improvement_percent'], 2),
            'block_range': [round(min(v['pooled']['block_improvement_percent']), 2), round(max(v['pooled']['block_improvement_percent']), 2)],
            'series_total': v['pooled']['series_total'],
            'family': {f: {'gain': round(x['improvement_percent'], 2), 'p': round(x['p'], 4)} for f, x in v['family'].items()},
            'share_of_benchmark_gain': round(v['pooled']['improvement_percent'] / A11['contrasts']['authors_vs_native']['relative_mse_gain_percent'], 3),
            'versus': {m: short(x['pooled']) for m, x in AF[c]['versus'].items()}}
authors_gain = {c: AF[c]['versus_native']['pooled']['improvement_percent'] for c in 'GHI'}
authors_p = {c: AF[c]['versus_native']['pooled']['p'] for c in 'GHI'}
authors = {
 'label': A11['label'], 'checkpoint': {k: A11['checkpoint'][k] for k in ['repository', 'revision', 'file', 'bytes', 'sha256']},
 'standard': {'mse': round(A11['macro']['mse'], 6), 'mae': round(A11['macro']['mae'], 6), 'native_mse': round(A11['macro']['native_mse'], 6),
              'local_tsrag_mse_mean_of_5': round(A11['macro']['local_tsrag_mse_mean_of_5'], 6),
              'gain_over_native_percent': round(A11['contrasts']['authors_vs_native']['relative_mse_gain_percent'], 2),
              'gain_over_native_ci': [round(x, 2) for x in A11['contrasts']['authors_vs_native']['bootstrap_95pct']],
              'datasets_improved': A11['contrasts']['authors_vs_native']['datasets_improved'],
              'gain_over_local_tsrag_percent': round(A11['contrasts']['authors_vs_local_tsrag']['relative_mse_gain_percent'], 2),
              'gain_over_local_tsrag_ci': [round(x, 2) for x in A11['contrasts']['authors_vs_local_tsrag']['bootstrap_95pct']],
              'published_gain_percent': round(A11['published']['gain_percent'], 2),
              'per_dataset_mse': {d: round(v['mse'], 4) for d, v in A11['datasets'].items()},
              'per_dataset_published_mse': {d: v['published_tsrag_mse'] for d, v in A11['datasets'].items()},
              'max_abs_per_dataset_difference_from_published': round(max(abs(v['mse'] - v['published_tsrag_mse']) for v in A11['datasets'].values()), 5)},
 'cohorts': {c: authors_cohort(c) for c in 'GHI'},
 # Written expectations of results/method11/analysis_plan.json, evaluated mechanically.
 'expectations': {'statements': APLAN['written_expectations'],
                  'E1_held': bool(A11['expectation_E1']['held']),
                  'E2_held': bool(all(g < A11['contrasts']['authors_vs_native']['relative_mse_gain_percent'] for g in authors_gain.values())),
                  'E3_held': bool(sum(not (authors_gain[c] > 0 and authors_p[c] < .05) for c in 'GHI') >= 2),
                  'cohorts_with_unadjusted_p_below_0.05': [c for c in 'GHI' if authors_gain[c] > 0 and authors_p[c] < .05]},
}
def med(c, f, k='seasonal_strength'):
    return CH['cohorts'][c]['families'][f][k]['median']
def span(values):
    return [round(min(values), 2), round(max(values), 2)]
COHORT_KEYS = ['A', 'B', 'D', 'E', 'F', 'G', 'H', 'I', 'backbone_check']
by_family = lambda f: [med(c, f) for c in COHORT_KEYS if f in CH['cohorts'][c]['families']]
planned = CH['association']['planned_methods']
assert planned == ['alignrag', 'tsrag_authors', 'roar', 'static_native'] and CH['association']['n'] == 10
others = [v for m in planned[1:] for v in CH['association']['spearman'][m].values()]
characteristics = {
 'label': CHPLAN['status'],
 'seasonal_strength_family_median_range': {'web_demand': span(by_family('web_demand')), 'grid_load': span(by_family('grid_load')),
     'market_activity': span(by_family('market_activity')), 'taxi_mobility': span(by_family('taxi_mobility')),
     'cohort_I_families': span([med('I', f) for f in CH['cohorts']['I']['families']])},
 'standard_seasonal_strength_median': {d: round(v['seasonal_strength']['median'], 2) for d, v in CH['standard'].items()},
 'standard_five_ETT_and_weather_range': span([CH['standard'][d]['seasonal_strength']['median'] for d in ['ETTh1', 'ETTh2', 'ETTm1', 'ETTm2', 'weather']]),
 'family_table': {k: {a: round(v[a], 3) for a in ['seasonal_strength', 'trend_strength', 'weekly_seasonal_strength', 'nearest_record_distance']} for k, v in CH['family_table'].items()},
 'expectations': {'E1': {k: (round(v, 2) if isinstance(v, float) else v) for k, v in CH['expectations']['E1'].items()},
                  'E2': {k: (round(v, 2) if isinstance(v, float) else v) for k, v in CH['expectations']['E2'].items()}},
 'spearman_planned': {m: {k: round(v, 2) for k, v in CH['association']['spearman'][m].items()} for m in planned},
 'spearman_planned_other_three_methods_range': span(others), 'spearman_n_families': CH['association']['n'],
}
assert characteristics['expectations']['E1']['held'] is False and characteristics['expectations']['E2']['held'] is False
# Post hoc diagnostic: our trainings at the settings of the released scripts (results/method12; three variants, five seeds, scored once).
M12P, M12C, M12S, M12 = [load(SOURCES[k]) for k in ['released_plan', 'released_commit', 'released_scores', 'released_summary']]
sha12 = lambda k: hashlib.sha256((ROOT / SOURCES[k]).read_bytes()).hexdigest()
assert M12['post_hoc'] is True and M12['scored_once'] is True and M12C['targets_read'] is False and M12C['all_before_scoring'] is True
assert M12['analysis_plan_sha256'] == M12C['analysis_plan_sha256'] == M12S['analysis_plan_sha256'] == sha12('released_plan')
assert M12['prediction_commit_sha256'] == M12S['prediction_commit_sha256'] == sha12('released_commit') and M12['scores_sha256'] == sha12('released_scores')
assert M12P['written_at_utc'] < M12C['committed_at_utc'] < M12S['scored_at_utc'] and len(M12C['heads']) == 15
V12 = ['tsrag_released', 'tsrag_evalmode', 'crossrag_released']
assert sorted(M12P['variants']) == sorted(V12) == sorted(M12['cohorts'])
m12 = M12['standard_seven']
released = {
 'label': M12['label'], 'post_hoc': True, 'multiplicity': M12['multiplicity'],
 'order': {'plan_written_at_utc': M12P['written_at_utc'], 'predictions_committed_at_utc': M12C['committed_at_utc'], 'scored_at_utc': M12S['scored_at_utc']},
 'variants': M12P['variants'], 'seeds_per_variant': 5, 'heads': len(M12C['heads']), 'selection': 'none',
 'standard_seven': {v: {'macro_mse': round(m12['macro'][v + '_mse'], 4), 'macro_mae': round(m12['macro'][v + '_mae'], 4),
                        'macro_mse_seed_range': [round(min(m12['per_seed_mse'][v]), 4), round(max(m12['per_seed_mse'][v]), 4)],
                        'gain_over_native_percent': round(m12['contrasts'][v + '_vs_native']['gain'], 2),
                        'gain_over_native_ci': [round(x, 2) for x in m12['contrasts'][v + '_vs_native']['CI95']],
                        'datasets_improved': m12['contrasts'][v + '_vs_native']['datasets_improved']} for v in V12},
 'gap_between_local_tsrag_and_authors_checkpoint_closed_percent': {v: round(100 * m12['gap_closed'][v + '_share'], 1) for v in ['tsrag_released', 'tsrag_evalmode']},
 'cohorts': {v: {c: {'gain_over_native_percent': round(M12['cohorts'][v][c]['gain_over_native_percent'], 2), 'ci': [round(x, 2) for x in M12['cohorts'][v][c]['CI95']],
                     'p': round(M12['cohorts'][v][c]['p'], 4), 'blocks_improved': M12['cohorts'][v][c]['blocks_improved'],
                     'series_improved': M12['cohorts'][v][c]['series_improved'], 'series_total': M12['cohorts'][v][c]['series_total']} for c in 'GHI'} for v in V12},
 'expectations': {k: {'statement': v['statement'], 'held': bool(v['held'])} for k, v in M12['expectations'].items()},
 'expectations_failed': M12['expectations_failed'],
}
assert released['expectations_failed'] == ['E2', 'E3'] == [k for k, v in released['expectations'].items() if not v['held']]
numbers = {
 'sources_sha256': {k: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for k, p in SOURCES.items()},
 'tsrag_authors_checkpoint_post_hoc': authors,
 'G': {'versus_native': {m: short(g_entry(m)[0]) for m in METHODS + ['transport_native'] if m != 'alignrag'},
       'alignrag_post_hoc': short(g_entry('alignrag')[0]),
       'G1': {b: short(v['pooled']) for b, v in G['hypotheses']['G1'].items() if isinstance(v, dict) and 'pooled' in v},
       'G1_beaten': G['hypotheses']['G1']['baselines_beaten'],
       'G2': short(G['hypotheses']['G2']['pooled']), 'G3': short(G['hypotheses']['G3']['pooled']), 'G5': short(G['hypotheses']['G5']['pooled']),
       'alpha': {m: round(G['blend_strength'][m]['mean'], 4) for m in ['static_native', 'context_native', 'transport_native']},
       'raw_mse': {m: round(v, 3) for m, v in G['raw_mean_error']['mse'].items() if m in ['native', 'roar']}},
 'H': {'H1': {m: short(H['hypotheses']['H1'][m]['pooled']) for m in METHODS},
       'equal_family': {m: round(H['hypotheses']['H1'][m]['equal_family']['improvement_percent'], 2) for m in METHODS},
       'H2': {m: {'Holm9_p': round(v['Holm9_p'], 4), 'rejected': v['rejected'], 'range': [round(x, 2) for x in v['block_gain_range_percent']], 'blocks_positive': v['blocks_positive']} for m, v in H['hypotheses']['H2'].items() if isinstance(v, dict) and 'Q' in v},
       'persistence': {m: {k: round(v[k], 3) for k in ['spearman', 'Holm9_p', 'spearman_family_centered', 'Holm9_p_family_centered']} for m, v in H['hypotheses']['H3'].items() if isinstance(v, dict) and 'spearman' in v},
       'ranking': {k: short(v['pooled']) for k, v in H['hypotheses']['H4'].items() if isinstance(v, dict) and 'pooled' in v},
       'follow_the_leader': short(H['secondary']['follow_the_leader']['vs_native_blocks_7_12']),
       'leader_counts': H['secondary']['follow_the_leader']['chosen_counts'],
       'stages': {k: round(v['vs_native']['pooled']['improvement_percent'], 2) for k, v in H['secondary']['alignrag_stages'].items() if 'vs_native' in v},
       'raw_mse': {m: round(v, 3) for m, v in H['raw_mean_error']['mse'].items() if m in ['native', 'roar', 'alignrag', 'static_native', 'context_native']},
       'held': HELD['H']},
 'I': {'H1': {m: short(I['hypotheses']['H1'][m]['pooled']) for m in METHODS},
       'MAE': {m: short(I['hypotheses']['H1'][m]['pooled_MAE']) for m in ['alignrag', 'roar', 'static_native']},
       'p6': {m: I['hypotheses']['H1'][m]['pooled']['p6'] for m in ['alignrag', 'static_native']},
       'Holm9_p6': {m: I['hypotheses']['H1'][m]['pooled']['Holm9_p6'] for m in ['alignrag', 'static_native']},
       'family': {m: {f: {'gain': round(v['improvement_percent'], 2), 'Holm9_p': round(v['Holm9_p'], 4)} for f, v in I['hypotheses']['H1'][m]['family'].items()} for m in ['roar', 'alignrag']},
       'equal_family': {m: round(I['hypotheses']['H1'][m]['equal_family']['improvement_percent'], 2) for m in METHODS},
       'H2': {m: {'Holm9_p': round(v['Holm9_p'], 4), 'rejected': v['rejected'], 'range': [round(x, 2) for x in v['block_gain_range_percent']], 'blocks_positive': v['blocks_positive']} for m, v in I['hypotheses']['H2'].items() if isinstance(v, dict) and 'Q' in v},
       'persistence': {m: {k: round(v[k], 3) for k in ['spearman', 'Holm9_p', 'spearman_family_centered', 'Holm9_p_family_centered']} for m, v in I['secondary']['persistence'].items() if isinstance(v, dict) and 'spearman' in v},
       'ranking': {k: short(v['pooled']) for k, v in I['hypotheses']['H3'].items() if isinstance(v, dict) and 'pooled' in v},
       'follow_the_leader': short(I['secondary']['follow_the_leader']['vs_native_blocks_7_12']),
       'leader_counts': I['secondary']['follow_the_leader']['chosen_counts'],
       'stages': {k: round(v['vs_native']['pooled']['improvement_percent'], 2) for k, v in I['secondary']['alignrag_stages'].items() if 'vs_native' in v},
       'target_strata': {k: {'queries': v['queries']} for k, v in I['secondary']['target_observation_strata'].items() if isinstance(v, dict) and 'queries' in v},
       'raw_mse': {m: round(v, 3) for m, v in I['raw_mean_error']['mse'].items() if m in ['native', 'roar', 'alignrag', 'crossrag']},
       'held': HELD['I']},
 'memory_control': {'queries': E['queries'],
       'gain': {c: {m: short(E['gain_over_native'][c][m]['vs_native']) for m in METHODS} for c in ['released', 'shape_train', 'shape_rolling']},
       'rolling_minus_released': {m: short(E['primary_rolling_minus_released'][m]) for m in METHODS},
       'kept_share_rolling': {m: round(E['gain_over_native']['shape_rolling'][m]['vs_native']['improvement_percent'] / E['gain_over_native']['released'][m]['vs_native']['improvement_percent'], 3) for m in ['roar', 'alignrag', 'context_native']},
       'kept_share_train': {m: round(E['gain_over_native']['shape_train'][m]['vs_native']['improvement_percent'] / E['gain_over_native']['released'][m]['vs_native']['improvement_percent'], 3) for m in ['roar', 'alignrag']}},
 'standard': standard_numbers,
 'standard_local_vs_published_mse_percent': {m: gap(m) for m in ['tsrag', 'raf', 'pfrp', 'alignrag', 'crossrag', 'roar', 'ratl']},
 'standard_gain_over_native_percent': {'published': {m: round(100 * (1 - published(m)[3] / PV['native']['mse']), 2) for m in ['tsrag', 'raf', 'alignrag', 'crossrag']},
                                       'local': {m: round(100 * (1 - local(m)[0] / local('native')[0]), 2) for m in METHODS}},
 'cost_ms_per_query': {m: round(v['latency_ms_per_query'], 2) for m, v in COST['aggregate'].items()},
 'cost': {'latency_ratio_to_native': {m: round(v['latency_ratio_to_native'], 2) for m, v in COST['aggregate'].items()},
          'trainable_parameters': {m: PARAMS['2021'][m] for m in ['tsrag', 'crossrag', 'roar', 'pfrp', 'ratl']},
          'recorded_training_minutes_range': {m: [round(min(TC['recorded_training_seconds'][s][m] for s in PARAMS) / 60, 1), round(max(TC['recorded_training_seconds'][s][m] for s in PARAMS) / 60, 1)] for m in ['tsrag', 'crossrag', 'roar', 'pfrp', 'ratl']},
          'measurement': {k: COST[k] for k in ['device', 'batch', 'ids', 'warmups', 'repetitions', 'latency_excludes']},
          'training_seconds_note': TC['training_seconds_note']},
 'characteristics_post_hoc': characteristics,
 'released_settings_post_hoc': released,
 'totals': {'series_GHI': len(G['series']) + len(H['series']) + len(I['series']), 'queries_GHI': G['queries'] + H['queries'] + I['queries']},
}
(HERE / 'fresh_numbers.json').write_text(json.dumps(numbers, indent=1) + '\n')
print('fresh tables written: data, prior, position, standard, fresh, family, memory; fresh_numbers.json')
