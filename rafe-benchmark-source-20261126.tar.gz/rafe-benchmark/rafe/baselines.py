"""Fixed context-only baselines and a ridge fitted to matured memory pairs."""
import numpy as np

class ReferenceBaselines:
    def __init__(self, ridge=1.0):
        if ridge <= 0: raise ValueError("Positive ridge penalty required")
        self.ridge = float(ridge)

    def predict(self, batch):
        x = np.asarray(batch.context, np.float64)
        h, length = batch.horizon, x.shape[1]
        period = int(round(86400/batch.step_seconds))
        if period < 1 or period > length:
            raise ValueError("Daily seasonal baseline needs a complete daily cycle")
        result = {}
        if 'persistence' in batch.requested:
            result['persistence'] = np.repeat(x[:, -1:], h, 1)
        if 'seasonal_daily' in batch.requested:
            result['seasonal_daily'] = x[:, -period:][:, np.arange(h)%period]
        if 'context_ar' in batch.requested:
            lags = np.unique(np.r_[np.arange(1, 13), period]);begin = int(lags.max())
            if length-begin < 16: raise ValueError("Insufficient history for context AR")
            rows = []
            for series in x:
                mu, sd = series.mean(), max(series.std(), 1e-6)
                z = (series-mu)/sd;indices = np.arange(begin,length)
                design = np.c_[np.ones(len(indices)),z[indices[:,None]-lags]]
                penalty = np.eye(design.shape[1])*self.ridge;penalty[0,0]=0
                beta = np.linalg.solve(design.T@design+penalty,design.T@z[indices])
                history = list(z)
                for i in range(h):
                    y = beta[0]+np.asarray(history)[len(history)-lags]@beta[1:]
                    history.append(float(np.clip(y,-10,10)))
                rows.append(np.asarray(history[-h:])*sd+mu)
            result['context_ar'] = np.asarray(rows)
        if 'bank_ridge' in batch.requested:
            r = np.asarray(batch.records,np.float64);rows=[]
            for query, records in zip(x,r):
                mu, sd = query.mean(),max(query.std(),1e-6)
                features = (records[:,:length]-mu)/sd
                future = (records[:,length:]-mu)/sd
                center_x,center_y=features.mean(0),future.mean(0)
                features=features-center_x;future=future-center_y
                alpha=np.linalg.solve(features@features.T/length+self.ridge*np.eye(len(records)),future)
                prediction=((query-mu)/sd-center_x)@features.T/length@alpha+center_y
                rows.append(prediction*sd+mu)
            result['bank_ridge']=np.asarray(rows)
        if set(result)!=set(batch.requested):raise ValueError("Unknown reference baseline")
        return {n:np.asarray(v,np.float32) for n,v in result.items()}
