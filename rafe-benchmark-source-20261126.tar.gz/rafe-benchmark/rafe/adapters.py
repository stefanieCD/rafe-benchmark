"""Training-free RAF/Align-RAG ports on pinned local foundation models.

The cross-backbone and extended-horizon cases are explicit adaptations. They
do not claim to reproduce unreported released settings or transfer TS-RAG heads.
"""
from pathlib import Path
import gc
import sys
import numpy as np

class FoundationMethods:
    def __init__(self, project_root, backbone="bolt", prefix=None, device=None):
        import torch
        self.torch = torch
        self.root = Path(project_root).resolve()
        self.backbone = backbone
        self.prefix = prefix or backbone
        self.device = device or ("cuda" if torch.cuda.is_available() else
                                 "mps" if torch.backends.mps.is_available() else "cpu")
        torch.set_num_threads(2)
        self.model = None
        self.compilation = None
        if backbone == "bolt":
            from repro import train_release as T
            self.model = T.foundation().eval().requires_grad_(False).to(self.device)
        elif backbone == "timesfm":
            sys.path.insert(0, str(self.root / "third_party/timesfm8/src"))
            from timesfm.timesfm_2p5.timesfm_2p5_torch import TimesFM_2p5_200M_torch
            self.model = TimesFM_2p5_200M_torch.from_pretrained(
                str(self.root / "assets/timesfm258"), torch_compile=False)
            self.model.model.to(self.device)
            self.model.model.device = torch.device(self.device)
        else:
            raise ValueError(f"Unknown backbone: {backbone}")
        self.native_cache = {}

    def forecast_context(self, context, horizon):
        torch = self.torch
        x = np.ascontiguousarray(context, np.float32)
        if self.backbone == "bolt":
            # Bolt's released prediction block is 64; longer requests recurse
            # on its own median predictions, with the requested context retained.
            cap = 2048 if x.shape[1] + max(0, horizon - 64) <= 2048 else 4096
            if x.shape[1] + max(0, horizon - 64) > cap:
                raise ValueError("Extended context exceeds the declared Bolt cap")
            self.model.chronos_config.context_length = cap
            self.model.config.chronos_config["context_length"] = cap
            chunks, current = [], x
            with torch.inference_mode():
                for _ in range((horizon + 63) // 64):
                    y = self.model(context=torch.from_numpy(current).to(self.device)).quantile_preds[:, 4]
                    y = y.cpu().numpy().astype(np.float32)
                    chunks.append(y)
                    current = np.concatenate([current, y], 1)
            return np.concatenate(chunks, 1)[:, :horizon]
        from timesfm.configs import ForecastConfig
        context_cap = int(np.ceil(x.shape[1] / 32) * 32)
        signature = (context_cap, horizon, len(x))
        if self.compilation != signature:
            self.model.compile(ForecastConfig(
                max_context=context_cap, max_horizon=horizon,
                per_core_batch_size=32, normalize_inputs=True,
                use_continuous_quantile_head=True, force_flip_invariance=True,
                infer_is_positive=True, fix_quantile_crossing=True))
            original = self.model.compiled_decode
            self.model.compiled_decode = lambda h, values, masks: original(
                h, np.asarray(values, np.float32), masks)
            self.compilation = signature
        with torch.inference_mode():
            point, quantiles = self.model.forecast(horizon=horizon, inputs=list(x))
        if point.shape != (len(x), horizon) or quantiles.shape != (len(x), horizon, 10):
            raise ValueError("TimesFM output shape mismatch")
        return point.astype(np.float32)

    def predict(self, batch):
        from repro.matched_models import raf_context
        from repro import method10_alignrag as A
        from repro.method14_models import mmr
        import hashlib
        torch = self.torch
        x, records, horizon = batch.context, batch.records, batch.horizon
        if x.shape[1] != 512:
            raise ValueError("The published-method ports require L=512")
        names = {suffix: f"{self.prefix}_{suffix}" for suffix in ("native", "raf", "align")}
        requested = set(batch.requested)
        if requested - set(names.values()):
            raise ValueError("Unsupported output name for this foundation adapter")
        result = {}
        need_native = names["native"] in requested or names["align"] in requested
        if need_native:
            key = (hashlib.sha256(x.tobytes()).hexdigest(), horizon)
            if key not in self.native_cache:
                self.native_cache[key] = self.forecast_context(x, horizon)
            native = self.native_cache[key]
            if names["native"] in requested:
                result[names["native"]] = native
        if names["raf"] in requested:
            context, mean, sd = raf_context(x, records)
            result[names["raf"]] = self.forecast_context(context, horizon) * sd + mean
        if names["align"] in requested:
            q = torch.from_numpy(np.ascontiguousarray(x)).to(self.device)
            r = torch.from_numpy(np.ascontiguousarray(records)).to(self.device)
            with torch.inference_mode():
                selection = mmr(q, r, batch.slots)
                aligned, _ = A.cc_shift(q, A.affine(q, r))
                selected = torch.gather(aligned, 1, selection[:, :, None].expand(-1, -1, 512 + horizon))
                detailed = max(1, batch.slots // 5)
                a, b = selected[:, :detailed], selected[:, detailed:]
                a = torch.cat([a[:, :, 256:512], a[:, :, 512:]], 2).flip(1)
                b = torch.cat([b[:, :, 480:512], b[:, :, 512:]], 2).flip(1)
                context = torch.cat([b.reshape(len(q), -1), a.reshape(len(q), -1), q], 1)
                future = A.blend(aligned, torch.from_numpy(np.ascontiguousarray(batch.distance))).cpu().numpy()
                context = context.cpu().numpy()
            icl = self.forecast_context(context, horizon)
            result[names["align"]] = A.variants(native, icl, future)["alignrag"].astype(np.float32)
        return result

    def close(self):
        if self.model is not None:
            if self.backbone == "bolt":
                self.model.cpu()
            else:
                self.model.model.cpu()
            self.model = None
        self.native_cache.clear()
        gc.collect()
        if self.device == "mps":
            self.torch.mps.empty_cache()
