import tempfile, unittest
from pathlib import Path
import numpy as np
from rafe.prepare import read_series, prepare
from rafe.io import dump, load
from rafe.schema import Batch
from rafe.baselines import ReferenceBaselines
from rafe.prepare import demo
from rafe.runner import freeze

class FrequencyTests(unittest.TestCase):
    def test_case_interval_mismatch_rejected_before_prediction(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);path=Path(demo(root/'demo')['config']);config=load(path)
            config['cases'][0]['step_seconds']=360
            dump(root/'wrong.json',config)
            with self.assertRaisesRegex(ValueError,'sampling intervals disagree'):freeze(root/'wrong.json',root/'run')
    def test_csv_six_minute_spacing_and_error(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'series.csv';entry={'path':str(p),'time_column':'time','step_seconds':360}
            p.write_text('time,value\n2026-01-01T00:00:00Z,1\n2026-01-01T00:06:00Z,2\n')
            x,observed,start=read_series(Path(t)/'manifest.json',entry)
            np.testing.assert_array_equal(x,[1,2]);self.assertEqual(start,1767225600//360)
            p.write_text('time,value\n2026-01-01T00:00:00Z,1\n2026-01-01T00:07:00Z,2\n')
            with self.assertRaisesRegex(ValueError,'regular'):read_series(Path(t)/'manifest.json',entry)

    def test_npz_interval_mismatch_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'s.npz';np.savez(p,values=np.arange(100),step_seconds=360,start_step=1000)
            with self.assertRaisesRegex(ValueError,'disagrees'):read_series(Path(t)/'m.json',{'path':str(p)})

    def test_daily_baseline_uses_sampling_interval(self):
        x=np.tile(np.arange(240),(1,3))[:,-512:].astype(np.float32)
        batch=Batch(x,np.zeros((1,10,576)),np.zeros((1,10)),np.zeros((1,10)),np.array([1000]),64,10,('seasonal_daily',),360)
        pred=ReferenceBaselines().predict(batch)['seasonal_daily']
        np.testing.assert_array_equal(pred,x[:,-240:][:,:64])

    def test_frequency_survives_preparation(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);p=root/'s.npz';np.savez(p,values=np.sin(np.arange(1000)/10).astype(np.float32),start_step=500,step_seconds=360)
            manifest={'step_seconds':360,'L':32,'H':8,'K':3,'cohort':'freq','draws':[11],'policies':['rolling'],
                'series':[{'path':str(p),'family':'wave','query_indices':[400,600],'block_indices':[0,1]}]}
            dump(root/'m.json',manifest);result=prepare(root/'m.json',root/'prepared')
            case=load(result['cases_file'])[0];self.assertEqual(case['step_seconds'],360)
            with np.load(case['queries']) as z:
                self.assertEqual(int(z['step_seconds']),360);np.testing.assert_array_equal(z['origin'],[900,1100])

    def test_bank_ridge_constant_matured_target(self):
        x=np.tile(np.linspace(0,1,512),(2,1));r=np.tile(np.r_[np.linspace(0,1,512),np.full(64,3.)],(2,10,1))
        batch=Batch(x,r,np.zeros((2,10)),np.zeros((2,10)),np.array([1000,2000]),64,10,('bank_ridge',),3600)
        np.testing.assert_allclose(ReferenceBaselines().predict(batch)['bank_ridge'],3,atol=1e-6)
