"""Stage the PVLDB source bundle from manuscript_en into a new directory.

Usage: python manuscript_en/source/stage_zip.py <new directory, relative to the repository root>
Run it after verify_delivery.py, which rewrites delivery_check.json (a member). The bundle is written to
<new directory>/PVLDB_Vol20_LaTeX_Source.zip; copy it to output/ by hand.
"""
import hashlib, sys, zipfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
stage = ROOT / sys.argv[1]
assert not stage.exists(), 'stage must be new'
PREFIX = 'PVLDB_Source'
MEMBERS = [
    'ACM-Reference-Format.bst', 'README.md', 'acmart.cls', 'asset_manifest.json',
    'build_assets.py', 'build_fresh_tables.py', 'delivery_check.json',
    'draw_architecture.py', 'draw_experiments.py', 'figure_style_sources.json',
    'figure_theme.py', 'figures/experiment_figure_design.json', 'figures/protocol.pdf',
    'figures/protocol.svg', 'figures/protocol_design.json', 'figures/rankings.pdf',
    'figures/rankings.svg', 'fresh_numbers.json', 'main.tex',
    'policy_effects_by_consumer.json', 'policy_effects_by_consumer.py',
    'published_numbers.json', 'pvldb.sty', 'references.bib',
    'tables/cross.tex', 'tables/data.tex', 'tables/family.tex', 'tables/fresh.tex',
    'tables/main.tex', 'tables/matched.tex', 'tables/memory.tex', 'tables/position.tex',
    'tables/second.tex', 'tables/standard.tex', 'verify_delivery.py',
]
MEMBERS += ['build_published_policy.py', 'published_policy_numbers.json', 'published_policy_budget_text.tex', 'published_policy_ranking_text.tex', 'tables/published_policy.tex', 'tables/budget_sensitivity.tex', 'figures/published_rankings.pdf', 'figures/published_rankings.svg']
MEMBERS += ['source/assemble.py'] + [str(p.relative_to(ROOT/'manuscript_en')) for p in sorted((ROOT/'manuscript_en/source/parts').glob('*.tex'))]
home = str(Path.home()).encode(); user = Path.home().name.encode()
names = [f'{PREFIX}/{n}' for n in MEMBERS]
for n in names:
    src = ROOT / 'manuscript_en' / n.split('/', 1)[1]
    data = src.read_bytes()
    assert home not in data and user not in data, n
    dst = stage / n; dst.parent.mkdir(parents=True, exist_ok=True); dst.write_bytes(data)
out = stage / 'PVLDB_Vol20_LaTeX_Source.zip'
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for n in names:
        z.write(stage / n, n)
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None and sorted(z.namelist()) == sorted(names)
    for n in names:
        assert z.read(n) == (ROOT / 'manuscript_en' / n.split('/', 1)[1]).read_bytes(), n
print(len(names), 'members', hashlib.sha256(out.read_bytes()).hexdigest(), out.stat().st_size)
