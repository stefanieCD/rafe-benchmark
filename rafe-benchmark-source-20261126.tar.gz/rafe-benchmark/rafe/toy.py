"""Dependency-free example plugin; no targets are available through Batch."""
import numpy as np

class Persistence:
    def __init__(self, prefix="persistence"):
        self.prefix = prefix

    def predict(self, batch):
        out = np.repeat(batch.context[:, -1:], batch.horizon, axis=1)
        return {name: out.astype(np.float32) for name in batch.requested}

class MemoryMean:
    def __init__(self):
        pass

    def predict(self, batch):
        future = batch.records[:, :, batch.context.shape[1]:]
        return {name: future.mean(1).astype(np.float32) for name in batch.requested}
