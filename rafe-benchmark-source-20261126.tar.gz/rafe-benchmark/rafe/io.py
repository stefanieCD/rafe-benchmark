"""Portable manifests and protection of the original research evidence."""
from pathlib import Path
import hashlib
import json
import os
import tempfile
from datetime import datetime, timezone

def now():
    return datetime.now(timezone.utc).isoformat()

def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def dump(path, value, *, replace=False):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    data = (json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + "\n").encode()
    fd, temp = tempfile.mkstemp(prefix=".rafe-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        if replace:
            os.replace(temp, path)
        else:
            # link is atomic and refuses to replace an existing commitment.
            os.link(temp, path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)

def load(path):
    return json.loads(Path(path).read_text())

def protect_output(path):
    path = Path(path).resolve()
    for ancestor in [path, *path.parents]:
        for filename in ("execution_lock.json", "deployment_lock.json"):
            lock = ancestor / filename
            if lock.is_file() and load(lock).get("format") != "rafe.run.v1":
                raise ValueError(f"Output is inside protected research evidence: {ancestor}")
    repo = Path(__file__).resolve().parents[1]
    protected = [repo / "assets", repo / "manuscript_en", repo / "manuscript_zh"]
    results = repo / "results"
    if results.exists():
        for p in results.iterdir():
            if not p.is_dir():
                continue
            own_run = False
            if (p / "execution_lock.json").exists():
                own_run = load(p / "execution_lock.json").get("format") == "rafe.run.v1"
            if p.name.startswith(("eab", "method")) or (not own_run and any(
                    (p / n).exists() for n in ("deployment_lock.json", "execution_lock.json"))):
                protected.append(p)
    for p in protected:
        if path == p.resolve() or p.resolve() in path.parents:
            raise ValueError(f"Output is inside protected research evidence: {path}")
    return path

def resolve(config_path, value):
    path = Path(value).expanduser()
    return path.resolve() if path.is_absolute() else (Path(config_path).parent / path).resolve()
