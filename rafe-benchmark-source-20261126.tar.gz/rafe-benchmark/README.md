# RAFE

**RAFE** (Retrieval-Augmented Forecasting Evaluation) is a memory-aware
benchmark for retrieval-augmented time series forecasting. It treats the
method–memory pair as a first-class experimental unit: a frozen forecaster
is scored under controlled memory policies, with explicit budgets for
physical rows, unique records, returned slots, and weight concentration.

This repository is the source artifact for the VLDB 2027 / PVLDB Volume 20
Experiment, Analysis & Benchmark manuscript:

> Yang Li and Yijie Shi.
> *RAFE: A Memory-Aware Evaluation Framework for Retrieval-Augmented Time
> Series Forecasting* [Experiment, Analysis & Benchmark].

The published package in this tree is **rafe-eval 0.2.0**. The research
workspace still contains an older root `pyproject.toml` marked 0.1.0; that
file is not used here and must not overwrite the 0.2.0 sources.

## What RAFE provides

- A standalone Python package (`rafe-eval`) for freezing a comparison plan,
  committing forecasts, paired scoring, reporting, verification, and
  portable snapshot replay.
- Native-backbone and public-checkpoint controls, per-origin temporal
  eligibility (`e + H ≤ t`), and plugin-based adapters.
- Manuscript sources, figures, tables, and a PDF rebuilt from the latest
  section files.

The package core depends only on Python 3.10+ and NumPy. Foundation-model
adapters, when used, manage their own inference dependencies and weights;
those weights are not included in this repository.

## Repository layout

```
rafe/                 rafe-eval 0.2.0 library and CLI
tests/                unit and integration tests for 0.2.0
pyproject.toml        package metadata (version 0.2.0)
dist/                 official 0.2.0 wheel and source archive
paper/                latest manuscript sources and rebuilt PDF
  source/parts/       authoritative section sources (00–10)
  main.tex            assembled merge, byte-identical to the parts
  figures/            five paper figures (PDF, plus PNG/SVG where available)
  tables/             table TeX (nine tables are used in the paper)
  references.bib
  main.pdf            rebuilt from the sources above
```

Active figures: `protocol.pdf`, `cost_budget.pdf`, `published_rankings.pdf`,
`horizon_freq.pdf`, `retrieval_scaling.pdf`.

Active tables: `position`, `data`, `standard`, `memory`, `fresh`, `family`,
`published_policy`, `matched`, `second`. Additional `.tex` files under
`paper/tables/` are retained as unused or historical sources and are not
included in the compiled paper.

The abstract in `paper/source/parts/01_abstract_keywords.tex` and
`paper/main.tex` is 201 words (whitespace-separated tokens in the abstract
body). Those section sources are authoritative.

## Install

```sh
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
python -m pip install -e .
```

Alternatively, install the bundled wheel, which is also version 0.2.0:

```sh
python -m pip install dist/rafe_eval-0.2.0-py3-none-any.whl
```

From a checkout, `python -m rafe` works without installation if the package
is on `PYTHONPATH`.

## A verifiable example

The following commands use only this repository and NumPy. They run a
synthetic integration example (three series, two dependency-free plugins).
They are a tool-pipeline check, not experimental evidence for the paper.

```sh
rafe demo --out demo_data
rafe freeze demo_data/config.json --run-dir demo_run
rafe predict --run-dir demo_run
rafe score --run-dir demo_run
rafe report --run-dir demo_run
rafe verify --run-dir demo_run
rafe replay --run-dir demo_run
```

`replay` recomputes committed statistics read-only and requires exact
numeric agreement. On the assembly machine this example produced 12
profiles and 28 comparisons with maximum numeric difference 0.0.

See `rafe/README.md` for the plugin API, prepared-bank format, and how to
extend a frozen comparison with a new method.

## Paper sources and PDF

Edit the numbered files in `paper/source/parts/`, then assemble:

```sh
python paper/source/assemble.py paper/main.tex
```

`paper/main.pdf` (13 pages) was compiled with pdfLaTeX / latexmk from these
sources. The earlier on-disk PDF at
`manuscript_en/source/build/main.pdf` (25 Nov 2026, 15:00, Taipei time) is
older than the 201-word abstract (25 Nov 2026, 16:57, Taipei time). The
rebuilt PDF in this tree is the one compiled from the later sources.
Typographic details are recorded in `paper/COMPILE.md`. If a later compile
differs, keep the section sources as the authoritative version.

`paper/build_new_figures_and_scaling.py` and
`paper/retrieval_scaling_results.json` rebuild and record the retrieval
scalability figure. Regenerating the timings requires the paper’s method-14
input arrays, which are not in this Git tree; wall-clock numbers will not
bit-match across machines.

## Verified scope

The claims below describe what has been checked, and what has not.

**Checked from this tree**

- Package metadata and sources are rafe-eval **0.2.0** (not 0.1.0).
- The 11 section sources assemble to a byte-identical `paper/main.tex`.
- The manuscript PDF rebuilds to 13 pages (12 body + references) without
  LaTeX errors.
- The synthetic `rafe demo` pipeline above runs and replays with zero
  numeric difference.

**Checked in the authors’ prior delivery records, not packaged in this Git tree**

- rafe-eval 0.2.0: 21 automated tests; isolated-environment validation of
  54 multi-frequency configurations; relocated-snapshot replay of committed
  comparisons with zero numerical discrepancy. Those runs used portable
  bundles and snapshots that are not part of this slim tree.
- An earlier 0.1.x expansion delivery sealed policy-extension executions
  (cohorts B, D, E, F; thirteen memory policies) and related horizon work.
  Frozen computation for that expansion remains the 0.1.0 evaluation code;
  0.1.1 changed reporting and validation only.

**Not claimed**

- This repository does not contain the full committed-forecast archives,
  foundation-model weights, or author checkpoints, and does not by itself
  reproduce every table in the paper.
- No claim is made of third-party human replication, cross-hardware
  bitwise agreement, or that incomplete historical cold-replays are
  finished.
- Retrieval-scalability wall-clock figures are host-specific measurements
  recorded in `paper/retrieval_scaling_results.json` (macOS arm64), not a
  portable RAFE snapshot.

## Data sources

The paper evaluates the standard seven public benchmarks (ETTh1/2, ETTm1/2,
Weather, Electricity, Exchange) together with ten author-collected cohorts
(A, B, D, E, F, G, H, I, J, K) across web, electricity load, trading, taxi,
weather-station, and water-level domains, including NOAA CO-OPS products
for cohorts J and K. Provider terms and licenses apply to those data.
Series, banks, and committed forecasts are not redistributed in this tree.

## License

No license has been selected for this repository. See `NOTICE`. Nothing
here grants permission to reuse the code or manuscript beyond what the
authors later specify in a `LICENSE` file.

## Citation

Please cite the PVLDB Volume 20 / VLDB 2027 EAB paper once the official
venue bibliographic data are available. The current title and authors are
given at the top of this README.
