#!/bin/zsh
# Build the manuscript from the numbered parts: assemble main.tex, compile offline, report problems and pages.
# Uses only the Python and tectonic kept in the project folder (运行环境/); no network, no absolute paths.
# Usage: zsh manuscript_en/source/build.sh      (from any directory)
# Output: manuscript_en/source/build/main.pdf and main.log
set -o pipefail
HERE=${0:A:h}; EN=${HERE:h}; REPO=${EN:h}; ENV=${REPO:h:h}/运行环境
export PYTHONDONTWRITEBYTECODE=1 ICDE_REPO=$REPO
mkdir -p "$HERE/build"
zsh "$ENV/python.sh" "$HERE/assemble.py" "$EN/main.tex" || exit 1
cd "$EN" || exit 1
zsh "$ENV/tectonic.sh" --keep-logs --print --outdir "$HERE/build" main.tex > "$HERE/build/compile.log" 2>&1 || { tail -30 "$HERE/build/compile.log"; exit 1; }
tail -8 "$HERE/build/compile.log"
zsh "$ENV/python.sh" - "$HERE/build/compile.log" "$HERE/build/main.log" <<'PY'
from pathlib import Path
import sys
text = Path(sys.argv[1]).read_text()
# The printed compiler transcript includes the expected unresolved citations
# before BibTeX; inspect only the final TeX pass for delivery diagnostics.
passes = text.split('note: Rerunning TeX')
assert len(passes) > 1, 'final TeX pass not found in compiler transcript'
Path(sys.argv[2]).write_text(passes[-1])
PY
echo "-- problems in the log (none expected):"
grep -n 'Overfull\|LaTeX Error\|Missing character\|undefined references\|Citation.*undefined\|Reference.*undefined\|multiply' "$HERE/build/main.log" | head
echo "-- pages:"
zsh "$ENV/python.sh" - "$HERE/build/main.pdf" <<'PY'
import re, sys
from pypdf import PdfReader
r = PdfReader(sys.argv[1]); print('pages', len(r.pages))
for i, p in enumerate(r.pages):
    t = p.extract_text()
    heads = re.findall(r'(?:^|\n)((?:[IVX]+\. [A-Z] ?[A-Z ]+|TABLE [IVX]+|Fig\. \d|[A-K]\. RQ\d|REFERENCES|ACKNOWLEDGMENT OF AI))', t)
    print(i + 1, len(t.split()), heads, '| last:', t.strip()[-70:].replace('\n', ' '))
PY
