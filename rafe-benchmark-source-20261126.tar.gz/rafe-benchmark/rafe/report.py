"""Human-readable reports use stored scores; they never fit or rescore models."""
from pathlib import Path
import csv
import html
import json
from collections import defaultdict
import numpy as np
from .io import load, protect_output, dump, resolve
from .schema import budget_summary

def report(run_dir):
    run = protect_output(run_dir)
    scores = load(run / "scores.json")
    spec = load(run / "config.json")
    lock = load(run / "execution_lock.json")
    budgets = defaultdict(list)
    for case in spec["cases"]:
        budget = lock.get("budgets", {}).get(case["id"])
        if budget is None:
            with np.load(resolve(run/"config.json", case["bank"]), allow_pickle=False) as z:
                bank = {k:z[k] for k in ("record_end","record_series","N","U") if k in z}
            budget = budget_summary(bank)
        key = tuple(case.get(k,"main") for k in ("suite","cohort","H","K","policy"))
        budgets[key].append({"draw":case["draw"], **budget})
    rows = []
    for original in scores["comparisons"]:
        r = dict(original)
        cs = r["cluster_sensitivity"] or {}
        r.update(CI95_low=r["CI95"][0], CI95_high=r["CI95"][1],
                 cluster_p=cs.get("p"), cluster_holm_p=cs.get("holm_p"), cluster_units=cs.get("units"))
        base = tuple(r[k] for k in ("suite","cohort","H","K"))
        for arm in ("lhs","rhs"):
            r[arm+"_pooled_budget_json"] = json.dumps(budgets[base+(r[arm+"_policy"],)],sort_keys=True)
        rows.append(r)
    fields = ["suite", "cohort", "H", "K", "family", "metric", "kind", "lhs_method", "rhs_method",
              "lhs_policy", "rhs_policy", "improvement_percent", "p", "holm_p", "family_size",
              "temporal_units", "series", "bank_draws", "blocks_improved", "CI95_low", "CI95_high",
              "cluster_p", "cluster_holm_p", "cluster_units", "lhs_pooled_budget_json", "rhs_pooled_budget_json"]
    with (run / "comparisons.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    profile_fields = list(scores["profiles"][0])
    with (run / "profiles.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, profile_fields)
        writer.writeheader()
        writer.writerows(scores["profiles"])
    document = ["# RAFE evaluation report", "", f"Study scope: **{scores['scope']}**.", "",
                "Positive improvement means lower error for the left method/policy.",
                "Confidence intervals are nominal; significance uses the declared Holm family.", "",
                f"{len(scores['profiles'])} profiles; {len(rows)} paired comparisons.", "",
                "## Pooled MSE policy contrasts", "",
                "|Suite|Cohort|H|K|Method|Contrast|Gain %|CI95|Holm p|Cluster Holm p|",
                "|---|---|---:|---:|---|---|---:|---|---:|---:|"]
    for r in rows:
        if r["family"] != "pooled" or r["metric"] != "MSE" or r["kind"] != "memory":
            continue
        cs = r["cluster_sensitivity"]
        ci = ", ".join(f"{x:.3f}" for x in r["CI95"])
        cp = f"{cs['holm_p']:.4g}" if cs else "n/a"
        document.append(f"|{r['suite']}|{r['cohort']}|{r['H']}|{r['K']}|{r['lhs_method']}|"
                        f"{r['lhs_policy']} / {r['rhs_policy']}|{r['improvement_percent']:.3f}|"
                        f"[{ci}]|{r['holm_p']:.4g}|{cp}|")
    document += ["", "## Interpretation", "", *["- " + n for n in scores["notes"]]]
    (run / "report.md").write_text("\n".join(document) + "\n")
    headers = "".join(f"<th>{html.escape(k)}</th>" for k in fields)
    def td(k, value):
        text = html.escape(str(value))
        if k.endswith("budget_json"):
            return '<td><details><summary>Per-draw pooled budgets</summary><pre>'+text+'</pre></details></td>'
        return '<td>'+text+'</td>'
    body = "".join("<tr>" + "".join(td(k,r[k]) for k in fields) + "</tr>" for r in rows)
    (run / "report.html").write_text("""<!doctype html><meta charset="utf-8"><title>RAFE evaluation</title>
<style>body{font:15px system-ui;margin:24px}table{border-collapse:collapse;font-size:13px}th,td{border:1px solid #ddd;padding:7px}th{position:sticky;top:0;background:#eef}input{padding:9px;width:400px}</style>
<h1>RAFE evaluation report</h1><p>Positive gain means lower error. Search by cohort, method, policy, or horizon. Budget summaries describe all queries of each arm/draw, including on domain comparison rows; they do not estimate neural influence.</p>
<p>Study scope: """ + html.escape(scores["scope"]) + """. Intervals are nominal; Holm p-values use the declared comparison families.</p>
<input id="filter" placeholder="Filter comparisons"><table><thead><tr>""" + headers + "</tr></thead><tbody>" + body + """</tbody></table>
<script>document.querySelector('#filter').addEventListener('input',e=>{let s=e.target.value.toLowerCase();document.querySelectorAll('tbody tr').forEach(r=>r.hidden=!r.textContent.toLowerCase().includes(s))})</script>""")
    costs = []
    cases = {c["id"]:c for c in spec["cases"]}
    for path in sorted((run/"predictions").glob("*.json")):
        receipt = load(path)
        case = cases.get(receipt.get("case"))
        if case is None or "seconds" not in receipt:
            continue
        with np.load(resolve(run/"config.json", case["queries"]),allow_pickle=False) as z:
            queries = len(z["context"])
        seconds = float(receipt["seconds"])
        costs.append({"case":case["id"],"suite":case["suite"],"cohort":case["cohort"],"H":case["H"],
            "step_seconds":case.get("step_seconds",3600),"policy":case["policy"],"draw":case["draw"],
            "outputs":";".join(receipt["outputs"]),"queries":queries,"seconds":seconds,
            "queries_per_second":queries/seconds if seconds>0 else None})
    dump(run/"costs.json",{"measurements":costs,"scope":"Observed plugin-bundle wall time; excludes model construction; shared outputs/cache cannot be attributed to individual methods; reference copy time is not model inference."},replace=True)
    if costs:
        with (run/"costs.csv").open("w",newline="") as f:
            writer=csv.DictWriter(f,list(costs[0]));writer.writeheader();writer.writerows(costs)
    return {"markdown": str(run / "report.md"), "html": str(run / "report.html"), "csv": str(run / "comparisons.csv"), "costs":str(run/"costs.json")}
