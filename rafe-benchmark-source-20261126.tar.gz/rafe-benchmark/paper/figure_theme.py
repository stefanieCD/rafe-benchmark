"""Shared publication styling; colors encode roles, never significance."""
from matplotlib.patches import FancyBboxPatch

INK='#24364B'
MUTED='#627184'
BLUE='#2E6B92'
ORANGE='#B86B35'
TEAL='#397D7A'
PURPLE='#735A9E'
PASTEL_BLUE='#EAF1FA'
PASTEL_TEAL='#EAF5F2'
PASTEL_PURPLE='#F1ECF8'
PASTEL_PEACH='#FAEADF'
PASTEL_GOLD='#FFF4D7'
EDGE='#B8C5D2'
FONT_STYLE={'font.family':'STIXGeneral','mathtext.fontset':'stix',
            'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none',
            'font.size':8.5,'axes.labelsize':8.5,'axes.titlesize':9.3,
            'axes.linewidth':.65,'xtick.labelsize':8.3,'ytick.labelsize':8.3,
            'xtick.major.width':.65,'ytick.major.width':.65}

def rounded(ax,x,y,w,h,fill='white',edge=EDGE,lw=.65,radius=4,shadow=False,zorder=1):
    if shadow:
        ax.add_patch(FancyBboxPatch((x+1.1,y-1.2),w,h,
                     boxstyle=f'round,pad=0,rounding_size={radius}',
                     facecolor=INK,edgecolor='none',alpha=.065,zorder=zorder-.1))
    patch=FancyBboxPatch((x,y),w,h,boxstyle=f'round,pad=0,rounding_size={radius}',
                        facecolor=fill,edgecolor=edge,lw=lw,zorder=zorder)
    ax.add_patch(patch)
    return patch

def figure_header(fig,x,y,w,h,title,fill=PASTEL_BLUE,color=INK):
    """Flat header outside the data axes, in figure coordinates."""
    fig.add_artist(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.003,rounding_size=0.010',
                   transform=fig.transFigure,facecolor=fill,edgecolor=EDGE,lw=.55,zorder=0))
    fig.text(x+.012,y+h/2,title,fontsize=9.3,weight='bold',color=color,
             ha='left',va='center')
