"""Render the completed post-hoc extension; read frozen scores, never run a model."""
from pathlib import Path
import hashlib,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
from figure_theme import FONT_STYLE
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
source=ROOT/'results/method14/scores.json';S=json.loads(source.read_text());assert S['post_hoc'] and S['all_predictions_committed_first']
M=['tsrag_authors','alignrag_common']; names={M[0]:'TS-RAG (authors)',M[1]:'Align-RAG (common K)'}
F=['web_demand','grid_load','market_activity']; short=['Web','Load','Trading']
P=['rolling','sim_high','sim_mid','age_recent','age_old','U16_slots','U16_unique','U32_slots','U32_unique','dup5_balanced','dup5_concentrated','dup10_unique','dup5_permuted']
checks=[]
def cell(v,ci=False,pk=None):
 x=v['improvement_percent'];t=f'{x:+.2f}'
 if ci:t+=' ['+', '.join(f'{a:+.2f}' for a in v['CI95'])+']'
 if pk and v.get(pk,1)<.05:t=r'\textbf{'+t+'}'
 return t
rows=[];budget=[]
for c,C in S['cohorts'].items():
 for m in M:
  mc=C['memory_contrasts'][m]
  row=[c,names[m],cell(C['methods'][m]['rolling_K10_H64']['pooled'],True,'Holm26_p')]
  row += [cell(mc[f]['sim_high_vs_sim_mid'],pk='Holm6_p') for f in F[:2]]
  row += [cell(mc[f]['U16_unique_vs_U16_slots'],pk='Holm6_p') for f in F if f in C['families']]
  if F[2] not in C['families']:row+=['--']
  row+=[str(C['ranking']['pooled']['controlled_policies_reversing_rolling_sign'])+'/12']
  rows.append(row)
  r=[c,names[m]]
  for f in F:
   if f not in C['families']:r+=['--'];continue
   vals=C['sensitivity'][m][f];n=C['expectations']['E4_budget_sign_stability'][m][f]['of9']
   r += [' / '.join(f"{vals[f'K{k}_H64']['improvement_percent']:+.2f}" for k in [5,10,16])+f' ({n}/9)']
  rr=C['ranking_sensitivity']['pooled'];n=sum(a['controlled_policies_reversing_rolling_sign']>0 for a in rr.values());r+=[f'{n}/9'];budget.append(r)
def table(file,caption,label,headers,rows,fmt,note):
 text=r'\begin{table*}[t]'+'\n'+r'\centering\footnotesize'+'\n'+r'\caption{'+caption+'}\n'+r'\label{'+label+'}\n'+r'\setlength{\tabcolsep}{3pt}'+'\n'+r'\begin{tabularx}{\textwidth}{'+fmt+'}\n'+r'\toprule'+'\n'+' & '.join(headers)+r' \\'+'\n'+r'\midrule'+'\n'+'\n'.join(' & '.join(r)+r' \\' for r in rows)+'\n'+r'\bottomrule'+'\n'+r'\end{tabularx}'+'\n'+r'\par\smallskip\begin{minipage}{\textwidth}\footnotesize '+note+r'\end{minipage}'+'\n'+r'\end{table*}'+'\n';(HERE/'tables'/file).write_text(text)
 checks.append({'file':'tables/'+file,'rows':rows})
table('published_policy.tex',r'Post hoc published-method policy extension: gain in geometric-mean MSE (\%)','tab:publishedpolicy',['Cohort','Consumer',r'\shortstack{Rolling vs. native\\{[95\% CI]}}',r'\shortstack{Similarity\\Web}','load',r'\shortstack{Unique16\\Web}','load','trading',r'\shortstack{Pair\\rank flips}'],rows,'@{}lYrrrrrrr@{}',r'Common $K=10$, $H=64$; positive values lower error. Similarity compares high with median similarity; Unique16 compares unique-record with row-wise top-$K$ from the same replicated 16-record population. Bold: twelve-block Holm26 for rolling vs. native, Holm6 for each memory contrast; intervals are nominal. Rank flips count TS-RAG/Align-RAG sign reversals from rolling over twelve controlled policies and apply to the pair, not independently to each row. --: family absent. All four cohorts and both methods are reported.')
table('budget_sensitivity.tex','Budget and forecast-prefix sensitivity of the published consumers (post hoc)','tab:budgetsensitivity',['Cohort','Consumer','Web: K5 / K10 / K16','Load: K5 / K10 / K16','Trading: K5 / K10 / K16','Pair rank flips'],budget,'@{}lYrrrl@{}',r'Cells give Unique16-vs.-slots error improvements (\%) at $H=64$ for $K=5,10,16$. Parentheses count signs agreeing with $K=10,H=64$ over all nine $K\times H$ cells ($H=16,32,64$ prefixes of one 64-step forecast). Pair rank flips count nine cells where U16 slots or unique retrieval reverses the TS-RAG/Align-RAG rolling ordering; repeated per pair. Ranking counts are descriptive. Changing $K$ also changes Align-RAG context packing (1,216/1,920/2,720 points); this does not isolate reference count from prompt length.')
# Primary consumers are first; local trained heads and calibrated average remain auxiliary.
plt.rcParams.update(FONT_STYLE);fig,axes=plt.subplots(4,1,figsize=(7.1,3.35),layout='constrained',sharex=True)
labels=['Rolling','Sim high','Sim mid','Recent','Old','U16 slots','U16 unique','U32 slots','U32 unique','5 balanced','5 conc.','10 unique','5 permuted'];data={}
for ax,(c,C) in zip(axes,S['cohorts'].items()):
 a=np.array([[C['methods'][m][f'{p}_K10_H64']['pooled']['improvement_percent'] for p in P] for m in M]);data[c]=a.tolist()
 im=ax.imshow(a,cmap='RdBu',norm=TwoSlopeNorm(vmin=-10,vcenter=0,vmax=10),aspect='auto');ax.set_yticks(range(2),['TS-RAG authors','Align-RAG K10'],fontsize=7);ax.set_title(f'Cohort {c}',loc='left',fontsize=8,pad=2)
 for i in range(2):
  for j in range(13):ax.text(j,i,f'{a[i,j]:+.1f}',ha='center',va='center',fontsize=7,color='white' if abs(a[i,j])>6 else '#152335')
 ax.set_xticks(range(13),labels,rotation=40,ha='right',fontsize=7);ax.tick_params(axis='both',length=0);ax.spines[['top','right','bottom','left']].set_visible(False)
fig.colorbar(im,ax=axes,shrink=.7,aspect=35,pad=.015,label='Gain over native (%)')
for ext in ['pdf','svg']:fig.savefig(HERE/f'figures/published_rankings.{ext}',metadata={'Creator':'matplotlib'} if ext=='pdf' else None)
plt.close(fig)
# Expose every expectation cell rather than choosing only successful domains.
E={c:C['expectations'] for c,C in S['cohorts'].items()};flat=lambda v: [x for a in v.values() for x in (flat(a) if isinstance(a,dict) else [a])] if isinstance(v,dict) else [v]
e1=[b for C in E.values() for fs in C['E1_similarity'].values() for b in fs.values()];e2=[b for C in E.values() for fs in C['E2_unique_domain'].values() for b in fs.values()];e3=[C['E3_ranking_reversal']['held'] for C in E.values()];e4=[r['held'] for C in E.values() for fs in C['E4_budget_sign_stability'].values() for r in fs.values()]
neg={m:max(C['negative_control'][m]['max_abs_forecast_difference'] for C in S['cohorts'].values()) for m in M}
bridge={c:C['budget_bridge']['pooled']['improvement_percent'] for c,C in S['cohorts'].items()};flip={c:C['ranking']['pooled']['controlled_policies_reversing_rolling_sign'] for c,C in S['cohorts'].items()}
(HERE/'published_policy_numbers.json').write_text(json.dumps({'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'prediction_commit_sha256':S['prediction_commit_sha256'],'post_hoc':True,'tables':checks,'figure_gains':data,'expectations':E,'expectation_summary':{'E1':[sum(e1),len(e1)],'E2':[sum(e2),len(e2)],'E3':[sum(e3),len(e3)],'E4':[sum(e4),len(e4)]},'negative_control_max_abs':neg,'default20_improvement_over_common10':bridge,'ranking_flips':flip},indent=2)+'\n')

(HERE/'published_policy_budget_text.tex').write_text(r"""The extension uses the authors' unchanged TS-RAG weights and training-free Align-RAG on B, D, E, F (38 series, 4,100 queries). These cohorts were already scored: this is post hoc, not a new confirmation. The numeric code, four expectations and exact inputs were sealed; all 400 forecasts preceded one score. Both consumers use five bank draws and one deterministic weight set. Every policy supplies ten records to both Align-RAG selection and blending; its separate released arm selects ten from twenty and blends all twenty. No model parameter or alignment rule changes. Equal-slot mass counts do not estimate neural influence. Nominal crossed-bootstrap intervals and exact twelve-block tests accompany Holm6 memory, Holm26 native, Holm13 ranking and Holm9 sensitivity corrections, separately by cohort and family.

\input{tables/published_policy.tex}

The similarity expectation holds in 15/16 method--family cells; the prior domain-specific Unique16 expectation in only 6/22. Unique16 improves Align-RAG in all eleven domain cells (1.04--3.26\%, seven Holm6-significant), while TS-RAG improves in five and degrades in six. No rolling gain over native passes Holm26 for either method in these four cohorts. All age-matched cells have support; all age, copy, content and U32 results remain in the artifact. High versus median similarity is a deliberately weak comparator. With six merged clusters no stated family can reject at 5\% after correction; bold cells rely on twelve blocks. The permutation control changes forecasts by at most """+f'{neg[M[0]]:.2g}'+r""" (TS-RAG) and """+f'{neg[M[1]]:.2g}'+r""" (Align-RAG). The released twenty-candidate arm improves on common ten by """+', '.join(fr'{c}: {v:+.2f}\%' for c,v in bridge.items())+r""", and is not pooled with it.

\input{tables/budget_sensitivity.tex}

Rolling and U16 slots/unique also use $K=5,16$: five is an exact subset of the frozen ten, and sixteen extends the same fixed population. The $H=16,32,64$ scores are prefixes of one 64-step forecast. At least seven of nine U16 signs agree with $K=10,H=64$ in 18/22 method--family cells; the four failures are retained. Align-RAG packing and its K16 context cap change with $K$ (Table~\ref{tab:budgetsensitivity}); these are explicit budget variants, not an isolated K effect or independently configured horizons.
""")
(HERE/'published_policy_ranking_text.tex').write_text(r"""At $K=10,H=64$, TS-RAG has lower overall error than common-budget Align-RAG under all thirteen policies in every cohort (Figure~\ref{fig:rankings}). All pairwise differences pass Holm13 in D, E, F; none does in B. No policy reverses their rolling ordering: the written expectation fails in all four cohorts. This limits the historical ROAR/Cross-RAG reversal claim. Budget/prefix changes produce reversals in only 3/36 pooled cells: B at $K=5,H=16$ and 32, and F at $K=5,H=16$ (Table~\ref{tab:budgetsensitivity}). Each is compared with its own rolling baseline. The artifact retains the full family grid, including one K10 trading-family reversal in D; raw sign reversals need not be significant. Thus neither stable ordering nor reversal is universal across consumers, budgets and domains.

\begin{figure*}[t]
\centering
\includegraphics[width=\textwidth]{figures/published_rankings.pdf}
\caption{Post hoc native-relative policy profiles of the two primary consumers ($K=10,H=64$). Positive values lower geometric-mean MSE. Colors encode error changes, not significance. Each cohort is shown separately; historical auxiliary profiles remain in the artifact.}
\label{fig:rankings}
\end{figure*}
""")
print('Rendered new tables, figure and prose; expectations',sum(e1),len(e1),sum(e2),len(e2),sum(e3),len(e3),sum(e4),len(e4))
