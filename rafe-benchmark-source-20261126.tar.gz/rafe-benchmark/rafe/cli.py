import argparse
import json

def main(argv=None):
    p = argparse.ArgumentParser(description="RAFE paired forecaster-memory evaluation")
    sub = p.add_subparsers(dest="command", required=True)
    q = sub.add_parser("freeze", help="validate contexts/memories and freeze configuration/input/code hashes")
    q.add_argument("config")
    q.add_argument("--run-dir", required=True)
    for command in ("predict", "score", "report", "verify", "replay"):
        q = sub.add_parser(command)
        q.add_argument("--run-dir", required=True)
    q = sub.add_parser("prepare", help="prepare queries and memory policies from a series manifest")
    q.add_argument("manifest")
    q.add_argument("--out", required=True)
    q = sub.add_parser("demo", help="create a small synthetic dataset and example plugin configuration")
    q.add_argument("--out", required=True)
    q = sub.add_parser("export", help="export a portable data/forecast/score snapshot for reuse and replay")
    q.add_argument("--run-dir", required=True)
    q.add_argument("--out", required=True)
    q = sub.add_parser("extend", help="prepare a new method comparison using committed inputs and baseline forecasts")
    q.add_argument("--run-dir", required=True)
    q.add_argument("--out", required=True)
    q.add_argument("--factory", required=True)
    q.add_argument("--name", required=True)
    q.add_argument("--baseline", action="append", required=True)
    q.add_argument("--suite", action="append")
    q.add_argument("--cohort", action="append")
    q.add_argument("--horizon", action="append", type=int)
    q.add_argument("--kwargs-json", help="file containing constructor keyword arguments")
    args = p.parse_args(argv)
    if args.command == "freeze":
        from .runner import freeze
        value = freeze(args.config, args.run_dir)
    elif args.command in ("predict", "score", "verify", "replay"):
        from . import runner
        value = getattr(runner, args.command)(args.run_dir)
        if args.command == "verify":
            value = {"verified_files": len(value[1]["files"]), "cases": len(value[0]["cases"])}
        elif args.command == "predict":
            value = {"prediction_files": len(value["files"]), "cases": len(value["outputs"]),
                     "all_forecasts_committed_before_scoring": value["all_forecasts_committed_before_scoring"]}
    elif args.command == "report":
        from .report import report
        value = report(args.run_dir)
    elif args.command == "demo":
        from .prepare import demo
        value = demo(args.out)
    elif args.command == "export":
        from .snapshot import export
        value = export(args.run_dir, args.out)
    elif args.command == "extend":
        from pathlib import Path
        from .extend import extend
        value = extend(args.run_dir,args.out,factory=args.factory,name=args.name,baselines=args.baseline,
                       suites=args.suite,cohorts=args.cohort,horizons=args.horizon,
                       kwargs=json.loads(Path(args.kwargs_json).read_text()) if args.kwargs_json else {})
    else:
        from .prepare import prepare
        value = prepare(args.manifest, args.out)
    print(json.dumps(value, ensure_ascii=False, indent=2))
