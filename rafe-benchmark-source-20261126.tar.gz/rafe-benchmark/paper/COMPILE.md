Manuscript PDF rebuild
=======================
Compiler: pdfLaTeX via latexmk (TeX Live 2025/dev, Debian) on the assembly box
Sources: paper/source/parts/00_preamble.tex .. 10_closing_references.tex
Merged main.tex is byte-identical to the assembled parts (authoritative).
Result: paper/main.pdf — 13 pages, 792188 bytes
Status: latexmk succeeded (exit 0)
Overfull boxes: 1 (one Overfull vbox of 1.152pt recorded)
Underfull boxes: 30 typographic warnings, no LaTeX errors
The previous manuscript_en/source/build/main.pdf (2026-11-25 15:00, Taipei time)
is older than the 201-word abstract in parts/01_abstract_keywords.tex and main.tex
(2026-11-25 16:57, Taipei time). This rebuilt PDF is compiled from those later sources.
