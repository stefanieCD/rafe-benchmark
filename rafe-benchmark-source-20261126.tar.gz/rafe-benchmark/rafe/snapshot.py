"""Portable snapshots retain all prepared banks and committed forecasts, without weights."""
from pathlib import Path
import copy
import shutil
from .io import dump, load, sha, now, protect_output, resolve
from .runner import verify, _verify_predictions

def export(run_dir, out_dir):
    run = Path(run_dir).resolve()
    spec, lock = verify(run)
    commit = _verify_predictions(run)
    scores = load(run/"scores.json")
    out = protect_output(out_dir)
    if out.exists() and any(out.iterdir()):
        raise FileExistsError("Export requires a new empty directory")
    out.mkdir(parents=True, exist_ok=True)
    copied, manifest = {}, {}

    def data_file(path):
        path = Path(path)
        key = (sha(path), path.suffix)
        if key not in copied:
            relative = f"data/{key[0]}{path.suffix}"
            dest = out/relative
            dest.parent.mkdir(exist_ok=True)
            shutil.copyfile(path, dest)
            copied[key] = relative
            manifest[relative] = key[0]
        return copied[key]

    config = copy.deepcopy(spec)
    for case in config["cases"]:
        for field in ("queries", "bank", "targets"):
            case[field] = data_file(case[field])
        for ref in case.get("references", {}).values():
            ref["path"] = data_file(ref["path"])
    for plugin in config["plugins"]:
        if "project_root" in plugin.get("kwargs", {}):
            plugin["kwargs"]["project_root"] = "ORIGINAL_RESEARCH_CHECKOUT_REQUIRED"
    config["provenance_files"] = []
    config["exported_for_replay_and_new_method_input_reuse"] = True
    dump(out/"config.json", config)
    manifest["config.json"] = sha(out/"config.json")
    for relative, expected in commit["files"].items():
        dest = out/relative
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(run/relative, dest)
        if sha(dest) != expected:
            raise ValueError(f"Exported forecast hash mismatch: {relative}")
        manifest[relative] = expected
    shutil.copyfile(run/"scores.json", out/"scores.json")
    manifest["scores.json"] = sha(out/"scores.json")
    for filename in ["analysis_plan.json", "coverage.json", "original_evidence.json"]:
        if (run/filename).exists():
            shutil.copyfile(run/filename, out/filename)
            manifest[filename] = sha(out/filename)
    core = [resolve(run/"execution_lock.json", p) for p in lock["files"]
            if Path(p).parent.name == "rafe" and Path(p).suffix == ".py"]
    if not core:
        raise ValueError("The original frozen framework source is unavailable")
    readme = core[0].parent/"README.md"
    for p in [*core, *([readme] if readme.exists() else [])]:
        dest = out/"source/rafe"/p.name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(p, dest)
        manifest[str(dest.relative_to(out))] = sha(dest)
    dump(out/"execution_lock.json", {"format": "rafe.run.v1", "files": manifest,
         "scope": scores["scope"], "replay_only": True, "exported_at_utc": now(),
         "original_execution_lock_sha256": sha(run/"execution_lock.json"),
         "original_prediction_commit_sha256": sha(run/"prediction_commit.json"),
         "original_scores_sha256": sha(run/"scores.json"),
         "omitted_provenance_hashes": [{"filename": Path(p).name, "sha256": h}
                                      for p, h in lock["files"].items() if h not in set(manifest.values())],
         "weights_and_model_source_dependencies_included": False})
    exported_commit = copy.deepcopy(commit)
    exported_commit["execution_lock_sha256"] = sha(out/"execution_lock.json")
    dump(out/"prediction_commit.json", exported_commit)
    dump(out/"scoring_started.json", {"exported_scored_snapshot": True,
         "prediction_commit_sha256": sha(out/"prediction_commit.json")})
    (out/"README.md").write_text("""# Portable RAFE evaluation snapshot

This snapshot contains all prepared query inputs, matured retrieval banks, targets,
committed forecasts and scores of the exported run. It excludes model weights and
the original foundation-model source dependencies. The source/ directory contains
the exact RAFE tool implementation.

Install the supplied RAFE wheel, or set PYTHONPATH=source, then run:

    python -m rafe verify --run-dir .
    python -m rafe replay --run-dir .
    python -m rafe report --run-dir .

All paths inside config.json and the snapshot lock are relative, so this folder can
be moved. Replay is read-only and checks the stored numerical profiles, contrasts,
intervals and p-values exactly. It does not rerun foundation-model inference.

To evaluate a new method, copy the case specifications from config.json into a NEW
run configuration, declare your own prediction plugin and comparison families,
and use freeze/predict/score/report in a new run directory. Keep scope=retrospective:
the target observations and existing forecasts in this snapshot are already known.
Frozen reference forecasts may be retained as baselines. Respect the original data
providers' terms for redistributed observations. Original method weights are not
included; the foundation adapters need the separately pinned research checkout.
""")
    return {"snapshot": str(out), "cases": len(config["cases"]),
            "forecast_files": len(commit["files"]), "data_files": len(copied),
            "bytes": sum(p.stat().st_size for p in out.rglob("*") if p.is_file())}
