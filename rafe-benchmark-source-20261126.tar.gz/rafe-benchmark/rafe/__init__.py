"""RAFE: explicit inputs, paired memory policies, committed forecasts."""
__version__ = "0.2.0"
