# RAFE evaluation tool

RAFE evaluates a forecasting method together with the historical memory it consumes.
It supports scalar series import, explicit returned-record budgets, user-defined
prediction plugins, paired temporal inference, and portable reports.

The portable tool needs Python 3.10+ and NumPy. The pinned foundation-model adapters
add PyTorch, Transformers and the research checkout's model sources/weights. They do
not download or train models. A user-defined plugin can use another forecasting library.

## Install and run the complete example

From the research checkout, `python -m rafe` works without installation. A built wheel
can be installed with `python -m pip install rafe_eval-0.2.0-py3-none-any.whl`.

```sh
rafe demo --out demo_data
rafe freeze demo_data/config.json --run-dir demo_run
rafe predict --run-dir demo_run
rafe score --run-dir demo_run
rafe report --run-dir demo_run
rafe verify --run-dir demo_run
rafe replay --run-dir demo_run
rafe export --run-dir demo_run --out portable_demo
```

The example uses three synthetic series and two dependency-free plugins. It is an
integration example, not experimental evidence for the paper. Reports contain JSON,
CSV, Markdown, and a searchable HTML comparison table.

The v0.1.1 CSV/HTML reports expose interval endpoints, raw/corrected p-values,
six-cluster sensitivity, and both arms' per-draw pooled memory budgets directly.
On domain comparison rows these budget summaries still describe the full arm,
rather than domain-specific or inferred neural influence. JSON retains all scores.
Input validation rejects inconsistent values under repeated keys, non-integer
temporal coordinates, and impossible or malformed prepared N/U budgets.

The paper's expansion execution is sealed with v0.1.0. Its frozen source is retained
inside the experiment snapshot. v0.1.1 strengthens input validation and report
presentation; prediction, error computation, statistical tests and comparison
families are unchanged. Original committed results are replayed without rescoring.

`replay` recomputes the committed numerical statistics read-only and requires exact
agreement. `export` packages all prepared banks, queries, targets, committed forecasts,
scores and the tool source into a movable snapshot with relative paths. The snapshot
can be numerically replayed using only NumPy, or used as input to a new retrospective
method comparison; original model weights are not included.

## Extend a committed comparison

To add a method to an existing committed run or exported snapshot, prepare a new
configuration. The first baseline is the native comparison; further baselines
are ranking comparisons. Only the new plugin requires inference:

```sh
rafe extend --run-dir portable_snapshot --out my_config.json \
  --factory my_module:MyForecaster --name my_method --baseline bolt_native \
  --baseline bolt_align --suite horizon --horizon 128
rafe freeze my_config.json --run-dir my_run
rafe predict --run-dir my_run
rafe score --run-dir my_run
rafe report --run-dir my_run
```

Optional repeated `--suite`, `--cohort` and `--horizon` flags restrict the workload.
Constructor arguments can be supplied through `--kwargs-json kwargs.json`.
Existing baseline forecasts, query inputs and prepared banks retain their hashes;
previously observed real data are automatically labeled retrospective. The command
does not execute the new plugin or overwrite the original run.

## Import your own series

`rafe prepare manifest.json --out prepared_data` accepts a series manifest with:

```json
{
  "cohort": "example", "L": 512, "H": 64, "K": 10,
  "draws": [101, 102, 103],
  "policies": ["rolling", "U16_slots", "U16_unique"],
  "series": [
    {"name": "demand", "family": "load", "path": "demand.npz",
     "query_indices": [2000, 2200, 2400, 2600],
     "block_indices": [0, 1, 2, 3]}
  ]
}
```

An NPZ series contains `values` (model inputs after the user's declared preprocessing),
optional `observed` (unimputed observations), and optional scalar `start_hour`.
Without `observed`, `values` is also the observation series. Query indices are offsets
within that series. RAFE never imputes targets. Missing observations are represented
by NaN; the context and historical record continuations must be finite.

CSV import accepts a `value_column` and optional `time_column`. Explicit timezone
timestamps must form a regular hourly series; otherwise use `start_hour`. For other
sampling frequencies, supply integer step coordinates consistently for origins,
record endpoints, query indices, and horizons through the prepared-bank interface.

Built-in preparation supports rolling memory, U16/U32 row-wise versus unique retrieval,
and fixed-content copy/concentration/permutation controls at K=10. Matching age and
similarity is study-specific: import explicitly matched banks, retain their support
restrictions in the workload, and freeze the comparison plan. The paper's original
thirteen policies are available through the prepared-bank importer; importing a policy
does not assert that its name alone establishes a valid matched comparison.

## Prepared-bank interchange format

Each case declares `cohort`, `suite`, `policy`, `draw`, `H`, and `K`, plus three NPZ paths:

|File|Required arrays|
|---|---|
|queries|`context [Q,L]`, `series [Q]`, `family [Q]`, `block [Q]`, `origin [Q]`|
|bank|`records [Q,K,L+H]`, `distance [Q,K]`, `record_end [Q,K]`|
|targets|`target [Q,H]`, NaN only at unobserved target steps|

Optional bank fields are `record_series [Q,K]`, `N`, and `U` (scalar or per-query).
RAFE checks `record_end + H <= origin` and reports unique returned `(series,end)` keys.
The endpoint is the first continuation step. Memory continuations are historical
observations, not forecasts or the current query's target. Preprocessing choices and
target coverage restrictions belong in the frozen workload manifest.

Paired memory draws must use the same query ordering and observation targets. Paired
policy comparisons additionally require equal context, series, block, and origin arrays.

## Add a forecasting method

A plugin is a Python class with a constructor and `predict(batch)` method:

```python
import numpy as np

class MyForecaster:
    def __init__(self, **kwargs):
        pass

    def predict(self, batch):
        # batch has no current target. The record tail is a matured continuation.
        forecast = np.repeat(batch.context[:, -1:], batch.horizon, axis=1)
        return {name: forecast for name in batch.requested}
```

Declare it with `{"factory":"my_module:MyForecaster","outputs":["my_method"],"kwargs":{}}`.
Return finite `[Q,H]` arrays with exactly the requested names. An optional `close()`
releases model resources. Names can be shared with case-specific frozen reference
forecasts; reference forecasts replace inference only in the cases where declared.
The runner passes no target through the plugin API. This contract does not sandbox a
malicious plugin's filesystem access: use trusted plugins and inspect their code.

## Declare comparisons before prediction

A run configuration includes `format_version: 1`, `scope` (`confirmation`, `retrospective`,
or `synthetic`), `plugins`, and `cases`. It can additionally declare:

```json
{
  "baselines": {"my_method": "native"},
  "policy_contrasts": [["U16_unique", "U16_slots"]],
  "rank_pairs": [["my_method", "other_method"]],
  "bootstrap": 10000,
  "stat_seed": 1729
}
```

For a method restricted to one workload suite, a rank pair can be declared as
`{"methods":["method_a","method_b"],"suites":["supported_suite"]}`.

Use `suite` to separate full workloads from deterministically sampled horizon workloads.
An independent horizon case requires its own eligible record continuations and targets;
the tool does not silently turn one forecast into multiple horizon experiments.

The freeze records configuration, plugin and framework source hashes, input hashes,
declared provenance files, and consumed memory budgets. Complete all model selection and
input preparation before freezing. A prospective acquisition study should also freeze
its acquisition protocol before downloading the evaluation observations. Declaring
`confirmation` here does not certify that earlier acquisition or model selection was blind.

Prediction is resumable only through matching commitment receipts. Input/code changes
invalidate the lock. All declared forecasts must be committed before target scoring.
Scoring writes a start marker and refuses a second invocation, including after an
interrupted score; preserve a failed run and create a separately identified run for repair.
The original research asset/result trees are protected from tool output in this checkout.

## Statistics and interpretation

Query MSE/MAE average over observed target steps. Cells are mean query errors for each
draw/series/temporal-block combination. Comparisons average paired log error ratios
equally over draws, series, and blocks; positive percentage gain favors the left side.
Every inferred series must have observations in every temporal block.

Sign flips are exact through 16 temporal units; larger layouts use a fixed-seed Monte
Carlo test with a plus-one correction. Draws do not increase the temporal sample size.
The paired bootstrap independently resamples draws, series, and temporal blocks;
intervals are nominal 95% intervals. Joint sign symmetry remains an assumption of the
temporal test. Adjacent block pairs provide a separately corrected sensitivity check.

Holm families are explicit and reported on every comparison:

- Native comparisons: all declared methods/policies sharing suite, cohort, H, K, domain,
  metric, and native baseline.
- Memory comparisons: all declared policy contrasts sharing those fields and consumer.
- Ranking comparisons: all policies sharing those fields and the same method pair.

Results include pooled and per-domain views, family sizes, raw and corrected p-values,
bootstrap intervals, and temporal sensitivity. A retrospective benchmark score does not
become a blind confirmation by using the freeze/commit workflow. Non-significance does
not establish equivalence; numerical budget counts do not estimate neural influence.

## Version 0.2.0: sampling frequency and cost records

Manifests can declare a positive integer `step_seconds` (default 3600). CSV timestamps must have exactly that spacing. NPZ series can use `start_step` and `step_seconds`; origins and record endpoints use integer sampling steps. A workload has one common frequency; paired arms must agree. Plugins receive `batch.step_seconds`, with no query targets. Daily seasonal, context-only ridge AR, and matured-memory ridge reference plugins are available in `rafe.baselines:ReferenceBaselines`.

Reports add `costs.json`/`costs.csv` for observed plugin-bundle wall time. These exclude model construction and retain shared-output/cache accounting; they are not per-method latency estimates or cross-hardware benchmarks. Earlier frozen execution sources and statistics are preserved.
