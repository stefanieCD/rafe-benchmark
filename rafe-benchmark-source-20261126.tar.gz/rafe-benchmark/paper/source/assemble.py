"""Assemble main.tex from the numbered parts in parts/ (the single editable source of the manuscript).

Usage: python assemble.py [output file]   (default: ../main.tex)
The parts are joined in file-name order: the preamble, then every other part separated by one blank line.
"""
import hashlib
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
parts = sorted((HERE / 'parts').glob('[0-9][0-9]_*.tex'))
assert [p.name[:2] for p in parts] == [f'{i:02d}' for i in range(11)], [p.name for p in parts]
body = [p.read_text().strip('\n') for p in parts]
text = body[0] + '\n' + '\n\n'.join(body[1:]) + '\n'
dst = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE.parent / 'main.tex'
dst.write_text(text)
print(dst.name, len(text.split('\n')) - 1, 'lines', hashlib.sha256(text.encode()).hexdigest())
