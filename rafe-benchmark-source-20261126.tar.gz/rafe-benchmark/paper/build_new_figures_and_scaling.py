"""Run real temporal-eligible retrieval scalability benchmark and render publication figures.

Outputs:
  - retrieval_scaling_results.json
  - figures/horizon_freq.{pdf,png}
  - figures/cost_budget.{pdf,png}
  - figures/retrieval_scaling.{pdf,png}
"""
from __future__ import annotations
import json
import platform
import time
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

from figure_theme import (
    INK, MUTED, BLUE, ORANGE, TEAL, PURPLE,
    PASTEL_BLUE, FONT_STYLE,
)

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
FIG_DIR = HERE / "figures"
FIG_DIR.mkdir(exist_ok=True)


def load_real_windows(max_windows: int = 100_000, n_queries: int = 200, seed: int = 2026):
    """Load real 512-step normalized contexts from Cohorts B, D, E, F."""
    rng = np.random.default_rng(seed)
    query_list = []
    rec_list = []
    for cohort in ["B", "D", "E", "F"]:
        cdir = ROOT / "results/method14/inputs" / cohort
        q_arr = np.load(cdir / "queries.npz")["context"].astype(np.float32)
        query_list.append(q_arr)
        for npz_path in sorted(cdir.glob("*_rolling_K10.npz")):
            recs = np.load(npz_path)["records"][:, :, :512].astype(np.float32)
            rec_list.append(recs.reshape(-1, 512))
    all_queries = np.concatenate(query_list, axis=0)
    all_recs = np.concatenate(rec_list, axis=0)

    def l2_norm(x: np.ndarray) -> np.ndarray:
        x = x - x.mean(axis=1, keepdims=True)
        norms = np.linalg.norm(x, axis=1, keepdims=True)
        norms = np.where(norms < 1e-8, 1.0, norms)
        return (x / norms).astype(np.float32)

    all_queries = l2_norm(all_queries)
    all_recs = l2_norm(all_recs)

    q_idx = rng.choice(len(all_queries), size=n_queries, replace=False)
    queries = np.ascontiguousarray(all_queries[q_idx])
    r_idx = rng.choice(len(all_recs), size=max_windows, replace=len(all_recs) < max_windows)
    bank = np.ascontiguousarray(all_recs[r_idx])
    return queries, bank


def paa_compress(x: np.ndarray, segments: int = 32) -> np.ndarray:
    """Piecewise Aggregate Approximation (512 -> segments) with L2 normalization."""
    n, L = x.shape
    w = L // segments
    p = x.reshape(n, segments, w).mean(axis=2)
    norms = np.linalg.norm(p, axis=1, keepdims=True)
    norms = np.where(norms < 1e-8, 1.0, norms)
    return np.ascontiguousarray((p / norms).astype(np.float32))


def topk_unique_from_scores(scores: np.ndarray, keys: np.ndarray, k: int = 10, oversample: int = 64):
    """Select top-k distinct (s, e) keys from a 1D score array using argpartition."""
    n = scores.shape[0]
    m = min(n, max(k, oversample))
    if m < n:
        cand = np.argpartition(scores, n - m)[n - m:]
        order = cand[np.argsort(scores[cand])[::-1]]
    else:
        order = np.argsort(scores)[::-1]
    seen = set()
    out = []
    for idx in order:
        key = int(keys[idx])
        if key not in seen:
            seen.add(key)
            out.append(int(idx))
            if len(out) == k:
                return out
    full_order = np.argsort(scores)[::-1]
    for idx in full_order:
        key = int(keys[idx])
        if key not in seen:
            seen.add(key)
            out.append(int(idx))
            if len(out) == k:
                break
    return out


def run_retrieval_scaling_benchmark():
    """Benchmark exact scan, time-indexed pre-filter, and PAA-32 two-stage index."""
    sizes = [1_000, 5_000, 10_000, 25_000, 50_000, 100_000]
    n_queries = 120
    K = 10
    M_rerank = 256
    H = 64
    queries, full_bank = load_real_windows(max_windows=max(sizes), n_queries=n_queries, seed=2026)
    queries_paa = paa_compress(queries, segments=32)
    rng = np.random.default_rng(2026)

    query_fracs = rng.uniform(0.25, 0.95, size=n_queries)
    results = {
        "host": {
            "platform": platform.platform(),
            "machine": platform.machine(),
            "numpy": np.__version__,
            "L": 512,
            "H": H,
            "K": K,
            "paa_dim": 32,
            "rerank_M": M_rerank,
            "n_queries": n_queries,
            "avg_temporal_selectivity": float(query_fracs.mean()),
        },
        "benchmarks": [],
    }

    for N in sizes:
        bank_u = np.ascontiguousarray(full_bank[:N])
        maturity_u = np.arange(N, dtype=np.int64)
        keys_u = np.arange(N, dtype=np.int64)
        paa_u = paa_compress(bank_u, segments=32)

        # Realistic 4x duplicated bank: randomly interleaved copies across timeline
        u_cnt = N // 4
        keys_dup = rng.permutation(np.tile(np.arange(u_cnt, dtype=np.int64), 4))
        bank_dup = np.ascontiguousarray(full_bank[keys_dup])
        paa_dup = paa_compress(bank_dup, segments=32)
        maturity_dup = np.arange(N, dtype=np.int64)

        cutoffs = np.clip((query_fracs * N).astype(np.int64), K * 8, N)

        # Warmup
        _ = bank_u @ queries[0]
        _ = bank_dup @ queries[0]

        # 1. Exact Full-Scan + Post-Filter
        t0 = time.perf_counter()
        exact_topk_sets = []
        for qi in range(n_queries):
            scores = bank_u @ queries[qi]
            mask = maturity_u <= cutoffs[qi]
            scores_masked = np.where(mask, scores, -np.inf)
            top = topk_unique_from_scores(scores_masked, keys_u, k=K, oversample=64)
            exact_topk_sets.append(set(top))
        t_full_post = (time.perf_counter() - t0) * 1000.0 / n_queries

        # 2. Time-Indexed Pre-Filter + Exact Scan (Unique bank)
        t0 = time.perf_counter()
        for qi in range(n_queries):
            end_pos = int(np.searchsorted(maturity_u, cutoffs[qi], side="right"))
            scores = bank_u[:end_pos] @ queries[qi]
            _ = topk_unique_from_scores(scores, keys_u[:end_pos], k=K, oversample=64)
        t_time_pre_u = (time.perf_counter() - t0) * 1000.0 / n_queries

        # 2b. Time-Indexed Pre-Filter on 4x Duplicated Bank (Row-wise vs Deduplicated)
        t0 = time.perf_counter()
        for qi in range(n_queries):
            end_pos = int(np.searchsorted(maturity_dup, cutoffs[qi], side="right"))
            scores = bank_dup[:end_pos] @ queries[qi]
            cand = np.argpartition(scores, end_pos - K)[end_pos - K:]
            _ = cand[np.argsort(scores[cand])[::-1]]
        t_time_pre_dup_row = (time.perf_counter() - t0) * 1000.0 / n_queries

        t0 = time.perf_counter()
        for qi in range(n_queries):
            end_pos = int(np.searchsorted(maturity_dup, cutoffs[qi], side="right"))
            scores = bank_dup[:end_pos] @ queries[qi]
            _ = topk_unique_from_scores(scores, keys_dup[:end_pos], k=K, oversample=64)
        t_time_pre_dup_dedup = (time.perf_counter() - t0) * 1000.0 / n_queries

        # 3. Time-Indexed PAA-32 Coarse Filter + Exact 512-step Re-Rank
        t0 = time.perf_counter()
        recalls = []
        for qi in range(n_queries):
            end_pos = int(np.searchsorted(maturity_u, cutoffs[qi], side="right"))
            coarse = paa_u[:end_pos] @ queries_paa[qi]
            m = min(end_pos, M_rerank)
            if m < end_pos:
                cand = np.argpartition(coarse, end_pos - m)[end_pos - m:]
            else:
                cand = np.arange(end_pos)
            fine = bank_u[cand] @ queries[qi]
            top_local = topk_unique_from_scores(fine, keys_u[cand], k=K, oversample=64)
            top_global = {int(cand[idx]) for idx in top_local}
            recalls.append(len(top_global & exact_topk_sets[qi]) / K)
        t_paa_rerank = (time.perf_counter() - t0) * 1000.0 / n_queries

        raw_mb = N * (576 * 4 + 16) / (1024 ** 2)
        paa_mb = N * (32 * 4) / (1024 ** 2)

        row = {
            "N": N,
            "full_scan_post_ms": round(t_full_post, 4),
            "time_prefilter_unique_ms": round(t_time_pre_u, 4),
            "time_prefilter_dup_rowwise_ms": round(t_time_pre_dup_row, 4),
            "time_prefilter_dup_dedup_ms": round(t_time_pre_dup_dedup, 4),
            "paa32_rerank_unique_ms": round(t_paa_rerank, 4),
            "paa32_recall_at_10": round(float(np.mean(recalls)), 4),
            "speedup_paa_vs_full": round(t_full_post / max(t_paa_rerank, 1e-6), 2),
            "raw_bank_mb": round(raw_mb, 2),
            "paa_index_mb": round(paa_mb, 2),
        }
        results["benchmarks"].append(row)
        print(
            f"N={N:>7d} | full={t_full_post:6.3f}ms | pre={t_time_pre_u:6.3f}ms | "
            f"paa={t_paa_rerank:6.3f}ms ({row['speedup_paa_vs_full']:4.1f}x) | "
            f"dup_row={t_time_pre_dup_row:6.3f}ms dup_dedup={t_time_pre_dup_dedup:6.3f}ms | "
            f"R@10={row['paa32_recall_at_10']:.3f} | RAM={raw_mb:.1f}+{paa_mb:.1f}MB"
        )

    out_json = HERE / "retrieval_scaling_results.json"
    out_json.write_text(json.dumps(results, indent=2) + "\n")
    return results


def render_horizon_freq_figure():
    """Figure 3: Multi-horizon Unique16 gains (left) & Multi-frequency J/K absolute MSE (right)."""
    plt.rcParams.update(FONT_STYLE)
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7.16, 2.30), layout="constrained",
                                   gridspec_kw={"width_ratios": [1.05, 1.15]})

    data_u16 = {
        "Bolt RAF":      {16: [1.58, -1.34, -0.61, -1.86, -0.83], 64: [-1.70, -0.57, -0.77, -1.88, -0.28], 128: [2.12, -1.06, 1.29, -1.47, -0.18]},
        "Bolt Align":    {16: [0.81,  1.85,  1.16,  1.52,  2.00], 64: [ 0.92,  0.96,  2.00,  3.32,  1.39], 128: [0.55,  1.37,  0.93,  2.47,  1.29]},
        "TimesFM RAF":   {16: [-1.49,-3.73, -0.31, -0.72,  0.23], 64: [ 4.85, -0.76,  2.61,  2.77, -0.26], 128: [-0.50, 0.36,  0.68,  0.92,  0.37]},
        "TimesFM Align": {16: [-0.67, 2.24,  1.45,  1.90,  1.91], 64: [ 0.66,  0.53,  0.89,  3.34,  0.99], 128: [0.51,  0.38,  1.09,  2.44,  0.76]},
    }
    horizons = [16, 64, 128]
    x = np.arange(len(horizons))
    width = 0.19
    methods = ["Bolt RAF", "Bolt Align", "TimesFM RAF", "TimesFM Align"]
    colors = [MUTED, BLUE, ORANGE, TEAL]
    hatches = ["///", "", "///", ""]

    for idx, (m, col, hatch) in enumerate(zip(methods, colors, hatches)):
        means = [np.mean(data_u16[m][h]) for h in horizons]
        offset = (idx - 1.5) * width
        ax1.bar(x + offset, means, width * 0.92, label=m, color=col,
                edgecolor=INK, linewidth=0.5, hatch=hatch, alpha=0.92, zorder=3)

    ax1.axhline(0, color=INK, linewidth=0.75, zorder=2)
    ax1.set_xticks(x, [f"$H={h}$" for h in horizons])
    ax1.set_ylabel("Mean Unique16 gain vs. slots (%)")
    ax1.set_ylim(-1.85, 2.35)
    ax1.set_title("(a) Multi-horizon deduplication across B\u2013I", loc="left", fontsize=8.4, weight="bold", color=INK)
    ax1.grid(axis="y", linestyle=":", alpha=0.45, zorder=0)
    ax1.spines[["top", "right"]].set_visible(False)
    ax1.legend(frameon=False, ncol=2, fontsize=7.0, loc="lower right", columnspacing=0.8, handlelength=1.4)

    labels_b = ["Native\nBolt", "Bolt\nRAF", "Author\nTS-RAG", "Bolt\nAlign", "Ridge\nAR", "Native\nTFM", "TFM\nRAF", "TFM\nAlign"]
    j_mse = [0.3655, 0.3524, 0.3512, 0.2848, 0.2519, 0.1466, 0.1512, 0.1343]
    k_mse = [0.7302, 0.5192, 0.5061, 0.4824, 0.0193, 0.0119, 0.0512, 0.1112]
    xb = np.arange(len(labels_b))
    wb = 0.36
    ax2.bar(xb - wb / 2, j_mse, wb, label="Cohort J (1h water level)", color=BLUE, edgecolor=INK, linewidth=0.5, alpha=0.92, zorder=3)
    ax2.bar(xb + wb / 2, k_mse, wb, label="Cohort K (6m tidal level)", color=ORANGE, edgecolor=INK, linewidth=0.5, alpha=0.92, zorder=3)
    ax2.set_yscale("log")
    ax2.set_ylim(0.007, 1.5)
    ax2.set_xticks(xb, labels_b, fontsize=7.0)
    ax2.set_ylabel("Geometric-mean MSE (log scale)")
    ax2.set_title("(b) Multi-frequency absolute MSE ($H=64$, rolling)", loc="left", fontsize=8.4, weight="bold", color=INK)
    ax2.grid(axis="y", linestyle=":", alpha=0.45, zorder=0)
    ax2.spines[["top", "right"]].set_visible(False)
    ax2.legend(frameon=False, fontsize=7.2, loc="upper right")

    for ext in ["pdf", "png"]:
        fig.savefig(FIG_DIR / f"horizon_freq.{ext}", dpi=300,
                    metadata={"Creator": "matplotlib"} if ext == "pdf" else None)
    plt.close(fig)


def render_cost_budget_figure():
    """Figure 4: TFB-style Accuracy vs. Inference Time Pareto (left) & K=5/10/16 Sweep (right)."""
    plt.rcParams.update(FONT_STYLE)
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7.16, 2.30), layout="constrained",
                                   gridspec_kw={"width_ratios": [1.14, 1.0]})

    pts = [
        # (name, time_x, gain_pct, params_M, paradigm, tx_lbl, ty_lbl, arrow)
        ("Native",      1.00,  0.00, 0.00, "Native",        1.48, -3.40, True),
        ("Const. blend",1.02,  0.75, 0.00, "Lightweight",   1.55,  2.20, True),
        ("TS-RAG",      1.15,  3.39, 4.78, "Adapter",       1.45,  4.10, True),
        ("ROAR",        1.22,  5.13, 2.27, "Adapter",       1.45,  6.40, True),
        ("Cross-RAG",   1.15,  0.40, 8.71, "Adapter",       2.05, -1.65, True),
        ("RATL",        1.09, -0.50, 0.11, "Adapter",       1.58, -5.60, True),
        ("PFRP",        1.11,-10.11, 0.77, "Adapter",       1.32,-10.11, False),
        ("RAF",         1.83,  0.95, 0.00, "Training-Free", 2.00,  1.05, False),
        ("Align-RAG",   4.50,  7.72, 0.00, "Training-Free", 3.68,  6.10, False),
    ]
    style_map = {
        "Native":        (INK,    "s", 40),
        "Lightweight":   (TEAL,   "D", 46),
        "Adapter":       (PURPLE, "o", 52),
        "Training-Free": (BLUE,   "^", 62),
    }
    ax1.axhline(0, color=MUTED, linestyle="--", linewidth=0.7, zorder=1)
    px = [1.00, 1.02, 1.22, 4.50]
    py = [0.00, 0.75, 5.13, 7.72]
    ax1.plot(px, py, linestyle=":", color=ORANGE, linewidth=1.15, zorder=2)

    for name, tx, g, par, kind, lx, ly, use_arrow in pts:
        col, mk, sz = style_map[kind]
        size = sz + par * 8.0
        ax1.scatter([tx], [g], s=size, color=col, marker=mk, edgecolor="white", linewidth=0.6, zorder=4)
        if use_arrow:
            ax1.annotate(name, xy=(tx, g), xytext=(lx, ly), fontsize=6.6, color=INK, va="center",
                         arrowprops=dict(arrowstyle="-", color=MUTED, lw=0.45, shrinkA=1, shrinkB=3))
        else:
            ax1.text(lx, ly, name, fontsize=6.6, color=INK, va="center")

    ax1.set_xlim(0.82, 4.88)
    ax1.set_ylim(-11.8, 9.6)
    ax1.set_xlabel("Inference time relative to native Chronos-Bolt ($\\times$)")
    ax1.set_ylabel("Standard-seven MSE gain (%)")
    ax1.set_title("(a) Accuracy vs. inference cost and adapter size", loc="left", fontsize=8.4, weight="bold", color=INK)
    ax1.grid(True, linestyle=":", alpha=0.45, zorder=0)
    ax1.spines[["top", "right"]].set_visible(False)

    legend_handles = [
        Line2D([0], [0], marker="^", color="w", markerfacecolor=BLUE, markersize=6.2, label="Training-free"),
        Line2D([0], [0], marker="o", color="w", markerfacecolor=PURPLE, markersize=6.2, label="Learned adapter"),
        Line2D([0], [0], marker="D", color="w", markerfacecolor=TEAL, markersize=5.6, label="Static blend"),
        Line2D([0], [0], linestyle=":", color=ORANGE, linewidth=1.15, label="Pareto frontier"),
    ]
    ax1.legend(handles=legend_handles, frameon=False, fontsize=6.7, loc="lower right")

    ks = [5, 10, 16]
    align_web  = [np.mean([1.31, 2.81, 1.80, 3.26]), np.mean([1.65, 2.12, 1.48, 2.48]), np.mean([1.81, 2.29, 2.07, 2.63])]
    align_load = [np.mean([3.63, 3.79, 3.03, 3.07]), np.mean([2.29, 3.21, 2.55, 1.91]), np.mean([2.74, 3.66, 2.62, 1.49])]
    align_trd  = [np.mean([2.18, 2.45, 5.48]),       np.mean([1.04, 1.51, 3.26]),       np.mean([0.54, 1.29, 2.10])]

    ts_web  = [np.mean([-0.40, -0.42, -0.01, 0.30]), np.mean([-0.29, -0.19, 0.11, 0.36]), np.mean([-0.12, 0.17, 0.47, 0.67])]
    ts_load = [np.mean([ 3.94,  0.96, -0.59,-2.65]), np.mean([ 2.24,  0.40, 0.21,-1.37]), np.mean([ 0.41, 0.12,-0.08,-0.77])]
    ts_trd  = [np.mean([ 0.21,  0.21,  0.41]),       np.mean([-0.04, -0.02,-0.03]),       np.mean([-0.12,-0.06,-0.06])]

    ax2.axhline(0, color=INK, linewidth=0.75, zorder=1)
    ax2.plot(ks, align_web,  marker="o", color=BLUE,   linewidth=1.5, label="Align-RAG: Web")
    ax2.plot(ks, align_load, marker="s", color=TEAL,   linewidth=1.5, label="Align-RAG: Load")
    ax2.plot(ks, align_trd,  marker="^", color=PURPLE, linewidth=1.5, label="Align-RAG: Trading")
    ax2.plot(ks, ts_web,     marker="o", color=BLUE,   linewidth=1.2, linestyle="--", alpha=0.82, label="TS-RAG: Web")
    ax2.plot(ks, ts_load,    marker="s", color=TEAL,   linewidth=1.2, linestyle="--", alpha=0.82, label="TS-RAG: Load")
    ax2.plot(ks, ts_trd,     marker="^", color=PURPLE, linewidth=1.2, linestyle="--", alpha=0.82, label="TS-RAG: Trading")

    ax2.set_xticks(ks, ["$K=5$", "$K=10$", "$K=16$"])
    ax2.set_ylabel("Mean Unique16 gain vs. slots (%)")
    ax2.set_ylim(-0.65, 4.75)
    ax2.set_title("(b) Retrieval-budget sweep across B\u2013F ($H=64$)", loc="left", fontsize=8.4, weight="bold", color=INK)
    ax2.grid(True, linestyle=":", alpha=0.45, zorder=0)
    ax2.spines[["top", "right"]].set_visible(False)
    ax2.legend(frameon=False, ncol=2, fontsize=6.6, loc="upper right", columnspacing=0.8, handlelength=1.6)

    for ext in ["pdf", "png"]:
        fig.savefig(FIG_DIR / f"cost_budget.{ext}", dpi=300,
                    metadata={"Creator": "matplotlib"} if ext == "pdf" else None)
    plt.close(fig)


def render_retrieval_scaling_figure(scaling_data: dict):
    """Figure 5: Temporal-eligible retrieval latency & index trade-offs from N=1e3 to 1e5."""
    plt.rcParams.update(FONT_STYLE)
    rows = scaling_data["benchmarks"]
    ns = np.array([r["N"] for r in rows])
    full_ms = np.array([r["full_scan_post_ms"] for r in rows])
    pre_ms = np.array([r["time_prefilter_unique_ms"] for r in rows])
    paa_ms = np.array([r["paa32_rerank_unique_ms"] for r in rows])
    dup_ded = np.array([r["time_prefilter_dup_dedup_ms"] for r in rows])
    recalls = np.array([r["paa32_recall_at_10"] * 100.0 for r in rows])
    raw_mb = np.array([r["raw_bank_mb"] for r in rows])
    paa_mb = np.array([r["paa_index_mb"] for r in rows])

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7.16, 2.26), layout="constrained",
                                   gridspec_kw={"width_ratios": [1.14, 1.0]})

    ax1.plot(ns, full_ms, marker="o", color=ORANGE, linewidth=1.6, label="Exact full scan + post-filter")
    ax1.plot(ns, pre_ms,  marker="s", color=BLUE,   linewidth=1.6, label="Time-indexed pre-filter (unique)")
    ax1.plot(ns, dup_ded, marker="D", color=PURPLE, linewidth=1.2, linestyle="--", label="Time-indexed + 4$\\times$-dup dedup")
    ax1.plot(ns, paa_ms,  marker="^", color=TEAL,   linewidth=1.8, label="Time-indexed PAA-32 + rerank")
    ax1.set_xscale("log")
    ax1.set_yscale("log")
    ax1.set_xticks(ns, ["1k", "5k", "10k", "25k", "50k", "100k"])
    ax1.set_xlabel("Memory bank size $N$ (windows, $L=512$)")
    ax1.set_ylabel("Retrieval latency (ms / query)")
    ax1.set_title("(a) Causal retrieval & deduplication latency", loc="left", fontsize=8.4, weight="bold", color=INK)
    ax1.grid(True, which="both", linestyle=":", alpha=0.45)
    ax1.spines[["top", "right"]].set_visible(False)
    ax1.legend(frameon=False, fontsize=6.6, loc="upper left")

    xb = np.arange(len(ns))
    ax2.bar(xb, raw_mb, width=0.52, color=PASTEL_BLUE, edgecolor=BLUE, linewidth=0.7, label="Raw bank (context+cont.)")
    ax2.bar(xb, paa_mb, bottom=raw_mb, width=0.52, color=TEAL, edgecolor=INK, linewidth=0.5, label="PAA-32 index")
    ax2.set_xticks(xb, ["1k", "5k", "10k", "25k", "50k", "100k"])
    ax2.set_xlabel("Memory bank size $N$")
    ax2.set_ylabel("Memory footprint (MB)", color=BLUE)
    ax2.set_ylim(0, max(raw_mb + paa_mb) * 1.18)
    ax2.set_title("(b) Storage footprint and PAA-32 Recall@10", loc="left", fontsize=8.4, weight="bold", color=INK)
    ax2.grid(axis="y", linestyle=":", alpha=0.45)
    ax2.spines["top"].set_visible(False)

    ax2_r = ax2.twinx()
    ax2_r.plot(xb, recalls, marker="o", color=ORANGE, linewidth=1.6, label="PAA-32 Recall@10 (%)")
    ax2_r.set_ylabel("Exact Top-10 Recall (%)", color=ORANGE)
    ax2_r.set_ylim(72, 104)
    ax2_r.spines["top"].set_visible(False)

    h1, l1 = ax2.get_legend_handles_labels()
    h2, l2 = ax2_r.get_legend_handles_labels()
    ax2.legend(h1 + h2, l1 + l2, frameon=False, fontsize=6.6, loc="center left", bbox_to_anchor=(0.01, 0.45))

    for ext in ["pdf", "png"]:
        fig.savefig(FIG_DIR / f"retrieval_scaling.{ext}", dpi=300,
                    metadata={"Creator": "matplotlib"} if ext == "pdf" else None)
    plt.close(fig)


if __name__ == "__main__":
    scaling = run_retrieval_scaling_benchmark()
    render_horizon_freq_figure()
    render_cost_budget_figure()
    render_retrieval_scaling_figure(scaling)
    print("All figures rendered successfully.")
