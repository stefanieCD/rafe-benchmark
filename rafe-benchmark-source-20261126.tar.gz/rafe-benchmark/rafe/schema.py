"""Prediction plugins receive contexts and matured memories, never targets."""
from dataclasses import dataclass
import numpy as np

@dataclass(frozen=True)
class Batch:
    context: np.ndarray
    records: np.ndarray
    distance: np.ndarray
    record_end: np.ndarray
    origin: np.ndarray
    horizon: int
    slots: int
    requested: tuple
    step_seconds: int = 3600

def validate_inputs(query, bank, horizon, slots):
    step = np.asarray(query.get("step_seconds", 3600))
    if step.ndim != 0 or not np.issubdtype(step.dtype, np.integer) or int(step) < 1:
        raise ValueError("Sampling step_seconds must be a positive scalar integer")
    x = query["context"]
    origin = query["origin"]
    records, distance, ends = bank["records"], bank["distance"], bank["record_end"]
    if x.ndim != 2 or not np.isfinite(x).all():
        raise ValueError("Contexts must be finite [queries, context_length]")
    q, length = x.shape
    if q < 1 or length < 1 or horizon < 1:
        raise ValueError("Contexts and horizons must be nonempty")
    if origin.shape != (q,) or any(query[k].shape != (q,) for k in ("series", "family", "block")):
        raise ValueError("Query metadata does not match context rows")
    if slots < 1 or records.shape != (q, slots, length + horizon):
        raise ValueError("Record shape must be [queries, K, L+H]")
    if distance.shape != (q, slots) or ends.shape != (q, slots):
        raise ValueError("Distances and record endpoints must match the returned slots")
    if not np.issubdtype(origin.dtype, np.integer) or not np.issubdtype(ends.dtype, np.integer):
        raise ValueError("Origin and record endpoints must use integer step coordinates")
    if np.any(np.abs(origin.astype(np.float64)) > 2**53-1) or np.any(np.abs(ends.astype(np.float64)) > 2**53-1):
        raise ValueError("Temporal coordinates exceed the exact supported range")
    if not np.isfinite(records).all() or not np.isfinite(distance).all():
        raise ValueError("Memory contains nonfinite inputs")
    if not np.all(ends.astype(np.float64) + horizon <= origin[:, None].astype(np.float64)):
        raise ValueError("A retrieved continuation is unavailable at the query origin")
    if "record_series" in bank and bank["record_series"].shape != (q, slots):
        raise ValueError("Record-series keys do not match returned slots")
    identities = bank.get("record_series",np.zeros_like(ends))
    counts = []
    for row in range(q):
        seen = {}
        for j,key in enumerate(zip(identities[row].tolist(), ends[row].tolist())):
            if key in seen and not np.array_equal(records[row,j],records[row,seen[key]]):
                raise ValueError("Repeated record keys carry inconsistent historical values")
            seen[key] = j
        counts.append(len(seen))
    numeric = {}
    for field in ("N","U"):
        if field in bank:
            a = np.asarray(bank[field])
            if a.shape not in ((),(q,)) or not np.issubdtype(a.dtype,np.integer) or np.any(a < 1):
                raise ValueError("Prepared N/U budgets must be positive integer scalars or per-query arrays")
            numeric[field] = np.broadcast_to(a,(q,))
            if np.any(numeric[field] < counts):
                raise ValueError("Prepared budget is smaller than distinct returned records")
    if "N" in numeric and "U" in numeric and np.any(numeric["U"] > numeric["N"]):
        raise ValueError("Prepared unique records exceed physical rows")
    blocks = np.unique(query["block"])
    if len(blocks) < 2 or any(not np.any((query["series"] == s) & (query["block"] == b))
                               for s in np.unique(query["series"]) for b in blocks):
        raise ValueError("Paired inference requires queries in every series/block cell")
    return q

def validate_forecasts(values, requested, q, horizon):
    if set(values) != set(requested):
        raise ValueError(f"Plugin outputs {sorted(values)}, expected {sorted(requested)}")
    for name, value in values.items():
        if np.asarray(value).shape != (q, horizon) or not np.isfinite(value).all():
            raise ValueError(f"Invalid forecast shape or nonfinite output for {name}")

def budget_summary(bank):
    ends = bank["record_end"]
    series = bank.get("record_series", np.zeros_like(ends))
    unique = np.array([len(set(zip(s.tolist(), e.tolist()))) for s, e in zip(series, ends)])
    def number(key):
        if key not in bank:
            return None
        a = np.asarray(bank[key])
        if a.ndim == 0 or np.all(a == a.flat[0]):
            return int(a.flat[0])
        return {"min": int(a.min()), "max": int(a.max()), "mean": float(a.mean())}
    return {"returned_slots": int(ends.shape[1]),
            "mean_unique_returned_records": float(unique.mean()),
            "min_unique_returned_records": int(unique.min()),
            "max_unique_returned_records": int(unique.max()),
            "prepared_rows": number("N"),
            "prepared_unique_records": number("U")}
